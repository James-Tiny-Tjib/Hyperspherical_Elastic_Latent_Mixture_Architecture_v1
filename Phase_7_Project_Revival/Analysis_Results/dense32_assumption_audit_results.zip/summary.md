# Dense-32 HELM Assumption Audit
Checkpoint: `JamesResearch1216/HELM_Vanilla_32/checkpoint-006500.pt`
Architecture: 32 heads × 64 dims = 2048 attention width; hidden=1024.
Diagnostic MLM CE: **3.441733**

## 1. Effective rank and head geometry
Raw rank is magnitude-sensitive. Directional rank normalizes every head first, so it measures directional diversity without forcing equal head strength.

|Layer|Context raw|Context directional|Residual raw|Residual directional|Mean |cos| residual|Top-1 energy|Top-4 energy|90% components|
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|0|24.95/32|29.41/32|11.63/32|13.47/32|0.387|8.0%|29.8%|16|
|1|24.10/32|28.33/32|9.25/32|12.51/32|0.407|10.9%|35.1%|18|
|2|22.32/32|30.86/32|11.08/32|22.21/32|0.190|22.2%|47.9%|18|
|3|25.23/32|31.79/32|18.86/32|30.67/32|0.045|15.6%|42.9%|18|
|4|24.94/32|31.87/32|21.47/32|31.44/32|0.022|17.4%|40.6%|22|
|5|23.49/32|31.84/32|18.11/32|30.91/32|0.029|15.5%|48.3%|19|
|6|25.26/32|31.90/32|19.77/32|31.46/32|0.017|17.5%|42.0%|19|
|7|24.66/32|31.85/32|22.68/32|29.52/32|0.041|12.0%|34.0%|20|
|8|25.03/32|31.90/32|22.78/32|31.66/32|0.018|10.4%|34.6%|21|
|9|26.05/32|31.82/32|23.60/32|31.18/32|0.024|9.2%|34.0%|22|
|10|25.55/32|31.74/32|22.48/32|30.71/32|0.034|13.0%|37.7%|23|
|11|22.78/32|31.74/32|22.23/32|31.25/32|0.022|10.2%|34.3%|23|

### How to read the rank split
- **low raw + high directional rank** → heads are mostly different directions but energy is concentrated in a few strong heads.
- **low raw + low directional rank** → genuine directional redundancy/collapse is also present.
- **context rank high, residual rank low** → the attention heads themselves are diverse but W_O compresses/concentrates their residual contributions.
- **context and residual ranks both low** → redundancy already exists before W_O.

## 2. Parameter allocation vs functional strength
- L00: rho(context RMS, residual RMS)=0.966; rho(W_O block norm, residual RMS)=0.523; energy Gini=0.424; coherence=10.716.
- L01: rho(context RMS, residual RMS)=0.916; rho(W_O block norm, residual RMS)=0.006; energy Gini=0.411; coherence=12.603.
- L02: rho(context RMS, residual RMS)=0.921; rho(W_O block norm, residual RMS)=-0.003; energy Gini=0.553; coherence=6.707.
- L03: rho(context RMS, residual RMS)=0.947; rho(W_O block norm, residual RMS)=0.580; energy Gini=0.544; coherence=1.627.
- L04: rho(context RMS, residual RMS)=0.938; rho(W_O block norm, residual RMS)=0.631; energy Gini=0.456; coherence=1.498.
- L05: rho(context RMS, residual RMS)=0.962; rho(W_O block norm, residual RMS)=0.676; energy Gini=0.559; coherence=1.278.
- L06: rho(context RMS, residual RMS)=0.902; rho(W_O block norm, residual RMS)=0.621; energy Gini=0.516; coherence=1.217.
- L07: rho(context RMS, residual RMS)=0.970; rho(W_O block norm, residual RMS)=0.675; energy Gini=0.430; coherence=1.697.
- L08: rho(context RMS, residual RMS)=0.980; rho(W_O block norm, residual RMS)=0.762; energy Gini=0.450; coherence=1.353.
- L09: rho(context RMS, residual RMS)=0.934; rho(W_O block norm, residual RMS)=0.652; energy Gini=0.421; coherence=1.343.
- L10: rho(context RMS, residual RMS)=0.912; rho(W_O block norm, residual RMS)=0.302; energy Gini=0.421; coherence=1.770.
- L11: rho(context RMS, residual RMS)=0.876; rho(W_O block norm, residual RMS)=0.274; energy Gini=0.438; coherence=1.670.

## 3. Exact single-head ablation
Dense CE on ablation subset: **3.856965**
- L00: mean ΔCE=-0.001145, max=+0.002165, fraction beneficial-to-keep=18.8%, fraction |ΔCE|<.001=43.8%, rho(RMS, ΔCE)=0.092.
- L05: mean ΔCE=+0.001709, max=+0.037466, fraction beneficial-to-keep=50.0%, fraction |ΔCE|<.001=28.1%, rho(RMS, ΔCE)=0.392.
- L11: mean ΔCE=+0.008880, max=+0.046704, fraction beneficial-to-keep=84.4%, fraction |ΔCE|<.001=15.6%, rho(RMS, ΔCE)=0.203.
Positive ΔCE means removing the head hurt MLM CE. This is more direct evidence of usefulness than RMS alone.

## 4. Post-hoc head-count curve
This removes heads from a model trained dense. It tests redundancy/robustness, **not** whether a separately trained smaller model would match it.
- keep 8/32: random=6.049563±0.143892, top_energy=5.028449
- keep 16/32: random=4.828930±0.116070, top_energy=4.032233
- keep 24/32: random=4.428237±0.000424, top_energy=3.741449
- keep 32/32: dense=3.574136

## 5. Assumptions this audit directly tests
1. **'Dense heads should have good effective rank.'** Check raw AND directional rank before treating rank as an optimization target.
2. **'Low effective rank means duplicate heads.'** False if directional rank/cosine are healthy; it may just be energy imbalance.
3. **'The attention computation is where collapse happens.'** Context-vs-residual rank tells us whether W_O is actually the bottleneck.
4. **'A large residual head is an important head.'** Exact ΔCE vs RMS tests that directly.
5. **'All 32 heads are needed because the model was trained dense.'** The ablations/head-count curve test this rather than assuming it.
6. **'Keeping the biggest heads is enough.'** Top-energy vs random same-count subsets tests whether magnitude contains useful pruning information.
7. **'Effective rank should be directly maximized.'** Only justified if low directional rank associates with worse CE; raw rank alone also penalizes legitimate specialization.
