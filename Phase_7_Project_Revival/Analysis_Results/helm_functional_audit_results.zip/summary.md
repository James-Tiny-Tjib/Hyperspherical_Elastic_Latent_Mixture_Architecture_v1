# HELM functional null + specialization audit

## Interpretation rules

- Directional rank near the random-init / random-direction null is **not evidence of specialization**.
- `raw_rank_minus_norm_matched_null_mean ≈ 0` means the trained raw-rank deficit is explained mostly by its per-head energy profile rather than extra directional alignment.
- Positive `dense_specialization_gap_active_minus_inactive` means the router tends to select head h on examples where h has larger exact utility under the same all-32 coalition.
- Positive `policy_specialization_gap_active_minus_inactive` means h is more useful in its actually selected routed coalitions than it would be when inserted into rejected coalitions.

## Rank/null snapshots

| model | layer | subset | space | raw eRank | dir eRank | random-null dir eRank | mean|cos| |
|---|---:|---|---|---:|---:|---:|---:|
| HELM-7c trained | 0 | all | context | 14.61/32 | 30.86/32 | 31.88/32 | 0.0332 |
| HELM-7c trained | 0 | all | residual | 6.03/32 | 20.95/32 | 31.99/32 | 0.1681 |
| HELM-7c trained | 0 | elastic | context | 11.10/24 | 23.58/24 | 23.93/24 | 0.0262 |
| HELM-7c trained | 0 | elastic | residual | 6.10/24 | 20.12/24 | 24.00/24 | 0.0992 |
| HELM-7c trained | 5 | all | context | 15.18/32 | 31.91/32 | 31.88/32 | 0.0092 |
| HELM-7c trained | 5 | all | residual | 12.39/32 | 31.68/32 | 31.99/32 | 0.0100 |
| HELM-7c trained | 5 | elastic | context | 11.66/24 | 23.96/24 | 23.93/24 | 0.0082 |
| HELM-7c trained | 5 | elastic | residual | 10.14/24 | 23.98/24 | 24.00/24 | 0.0046 |
| HELM-7c trained | 11 | all | context | 19.00/32 | 31.79/32 | 31.88/32 | 0.0155 |
| HELM-7c trained | 11 | all | residual | 13.44/32 | 31.63/32 | 31.99/32 | 0.0128 |
| HELM-7c trained | 11 | elastic | context | 12.87/24 | 23.86/24 | 23.93/24 | 0.0174 |
| HELM-7c trained | 11 | elastic | residual | 11.84/24 | 23.91/24 | 24.00/24 | 0.0098 |
| HELM-7c random-init | 0 | all | context | 27.85/32 | 28.54/32 | 31.88/32 | 0.0708 |
| HELM-7c random-init | 0 | all | residual | 30.99/32 | 31.77/32 | 31.99/32 | 0.0173 |
| HELM-7c random-init | 0 | elastic | context | 21.47/24 | 22.06/24 | 23.93/24 | 0.0706 |
| HELM-7c random-init | 0 | elastic | residual | 23.22/24 | 23.88/24 | 24.00/24 | 0.0169 |
| HELM-7c random-init | 5 | all | context | 28.15/32 | 28.56/32 | 31.88/32 | 0.0693 |
| HELM-7c random-init | 5 | all | residual | 31.21/32 | 31.78/32 | 31.99/32 | 0.0169 |
| HELM-7c random-init | 5 | elastic | context | 21.77/24 | 22.09/24 | 23.93/24 | 0.0693 |
| HELM-7c random-init | 5 | elastic | residual | 23.47/24 | 23.88/24 | 24.00/24 | 0.0161 |
| HELM-7c random-init | 11 | all | context | 27.80/32 | 28.15/32 | 31.88/32 | 0.0762 |
| HELM-7c random-init | 11 | all | residual | 31.38/32 | 31.77/32 | 31.99/32 | 0.0167 |
| HELM-7c random-init | 11 | elastic | context | 21.60/24 | 21.78/24 | 23.93/24 | 0.0776 |
| HELM-7c random-init | 11 | elastic | residual | 23.65/24 | 23.87/24 | 24.00/24 | 0.0167 |
| Dense-32 trained | 0 | all | context | 25.04/32 | 29.31/32 | 31.88/32 | 0.0604 |
| Dense-32 trained | 0 | all | residual | 11.29/32 | 13.20/32 | 31.99/32 | 0.3963 |
| Dense-32 trained | 5 | all | context | 23.71/32 | 31.89/32 | 31.88/32 | 0.0114 |
| Dense-32 trained | 5 | all | residual | 18.39/32 | 30.85/32 | 31.99/32 | 0.0299 |
| Dense-32 trained | 11 | all | context | 22.71/32 | 31.76/32 | 31.88/32 | 0.0153 |
| Dense-32 trained | 11 | all | residual | 22.15/32 | 31.21/32 | 31.99/32 | 0.0220 |
| Dense-32 random-init | 0 | all | context | 28.21/32 | 28.64/32 | 31.88/32 | 0.0673 |
| Dense-32 random-init | 0 | all | residual | 31.23/32 | 31.77/32 | 31.99/32 | 0.0169 |
| Dense-32 random-init | 5 | all | context | 28.01/32 | 28.43/32 | 31.88/32 | 0.0724 |
| Dense-32 random-init | 5 | all | residual | 31.29/32 | 31.75/32 | 31.99/32 | 0.0178 |
| Dense-32 random-init | 11 | all | context | 27.96/32 | 28.49/32 | 31.88/32 | 0.0699 |
| Dense-32 random-init | 11 | all | residual | 31.10/32 | 31.75/32 | 31.99/32 | 0.0182 |

## Functional specialization aggregates

| layer | mean active freq | mean dense A-I gap | frac dense gap > 0 | mean policy A-I gap | frac policy gap > 0 |
|---:|---:|---:|---:|---:|---:|
| 0 | 0.360 | -0.00021 | 0.478 | -0.00016 | 0.522 |
| 5 | 0.502 | +0.00112 | 0.600 | +0.00062 | 0.650 |
| 11 | 0.523 | +0.00081 | 0.600 | +0.00084 | 0.533 |

## Key causal question

If the router learned genuine head/example specialization, then for a meaningful fraction of elastic heads we should see:

`E[ΔCE_h | A_h] > E[ΔCE_h | I_h]`

under the common all-32 coalition, not merely high directional rank.