# Dense-16 HELM Assumption Audit
Checkpoint: `JamesResearch1216/phase06v4-Vanilla/checkpoint-006500.pt`
Architecture: 16 heads × 64 dims = 1024 attention width; hidden=1024.
Diagnostic MLM CE: **3.494338**

## 1. Effective rank and head geometry
Raw rank is magnitude-sensitive. Directional rank normalizes every head first, so it measures directional diversity without forcing equal head strength.

|Layer|Context raw|Context directional|Residual raw|Residual directional|Mean |cos| residual|Top-1 energy|Top-4 energy|90% components|
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|0|11.89/16|15.31/16|7.17/16|9.74/16|0.347|19.9%|57.2%|9|
|1|12.09/16|15.73/16|7.93/16|12.35/16|0.223|39.4%|64.7%|10|
|2|11.86/16|15.85/16|9.10/16|14.78/16|0.102|32.6%|63.4%|10|
|3|13.99/16|15.97/16|12.94/16|15.61/16|0.042|20.7%|47.5%|12|
|4|12.83/16|15.96/16|11.61/16|15.88/16|0.022|19.7%|55.7%|11|
|5|12.59/16|15.98/16|11.61/16|15.86/16|0.025|19.2%|54.9%|11|
|6|13.04/16|15.96/16|10.56/16|15.49/16|0.031|24.3%|59.2%|12|
|7|12.27/16|15.95/16|10.67/16|15.84/16|0.026|24.1%|58.4%|10|
|8|13.33/16|15.97/16|12.46/16|15.71/16|0.027|19.2%|51.9%|12|
|9|14.06/16|15.97/16|13.60/16|15.53/16|0.028|13.9%|44.5%|13|
|10|13.59/16|15.93/16|12.92/16|15.53/16|0.034|15.7%|50.2%|13|
|11|11.74/16|15.93/16|10.29/16|15.45/16|0.033|24.3%|60.7%|12|

### How to read the rank split
- **low raw + high directional rank** → heads are mostly different directions but energy is concentrated in a few strong heads.
- **low raw + low directional rank** → genuine directional redundancy/collapse is also present.
- **context rank high, residual rank low** → the attention heads themselves are diverse but W_O compresses/concentrates their residual contributions.
- **context and residual ranks both low** → redundancy already exists before W_O.

## 2. Parameter allocation vs functional strength
- L00: rho(context RMS, residual RMS)=0.962; rho(W_O block norm, residual RMS)=0.538; energy Gini=0.445; coherence=5.556.
- L01: rho(context RMS, residual RMS)=0.953; rho(W_O block norm, residual RMS)=0.485; energy Gini=0.508; coherence=3.108.
- L02: rho(context RMS, residual RMS)=0.956; rho(W_O block norm, residual RMS)=-0.015; energy Gini=0.530; coherence=1.989.
- L03: rho(context RMS, residual RMS)=0.882; rho(W_O block norm, residual RMS)=0.685; energy Gini=0.331; coherence=1.517.
- L04: rho(context RMS, residual RMS)=0.979; rho(W_O block norm, residual RMS)=0.524; energy Gini=0.440; coherence=1.146.
- L05: rho(context RMS, residual RMS)=0.953; rho(W_O block norm, residual RMS)=0.750; energy Gini=0.430; coherence=1.224.
- L06: rho(context RMS, residual RMS)=0.944; rho(W_O block norm, residual RMS)=0.741; energy Gini=0.443; coherence=1.032.
- L07: rho(context RMS, residual RMS)=0.976; rho(W_O block norm, residual RMS)=0.815; energy Gini=0.485; coherence=1.040.
- L08: rho(context RMS, residual RMS)=0.865; rho(W_O block norm, residual RMS)=0.794; energy Gini=0.383; coherence=1.213.
- L09: rho(context RMS, residual RMS)=0.835; rho(W_O block norm, residual RMS)=0.344; energy Gini=0.290; coherence=1.251.
- L10: rho(context RMS, residual RMS)=0.968; rho(W_O block norm, residual RMS)=-0.112; energy Gini=0.336; coherence=1.438.
- L11: rho(context RMS, residual RMS)=0.871; rho(W_O block norm, residual RMS)=0.118; energy Gini=0.463; coherence=1.629.

## 3. Exact single-head ablation
Dense CE on ablation subset: **3.841780**
- L00: mean ΔCE=+0.001768, max=+0.004178, fraction beneficial-to-keep=93.8%, fraction |ΔCE|<.001=37.5%, rho(RMS, ΔCE)=-0.079.
- L05: mean ΔCE=+0.003018, max=+0.011230, fraction beneficial-to-keep=75.0%, fraction |ΔCE|<.001=43.8%, rho(RMS, ΔCE)=0.450.
- L11: mean ΔCE=+0.028431, max=+0.098214, fraction beneficial-to-keep=100.0%, fraction |ΔCE|<.001=0.0%, rho(RMS, ΔCE)=0.109.
Positive ΔCE means removing the head hurt MLM CE. This is more direct evidence of usefulness than RMS alone.

## 4. Post-hoc head-count curve
This removes heads from a model trained dense. It tests redundancy/robustness, **not** whether a separately trained smaller model would match it.
- keep 4/16: random=6.230289±0.493939, top_energy=5.712305
- keep 8/16: random=6.236743±0.872952, top_energy=4.407943
- keep 12/16: random=4.578672±0.453399, top_energy=3.824229
- keep 16/16: dense=3.588053

## 5. Assumptions this audit directly tests
1. **'Dense heads should have good effective rank.'** Check raw AND directional rank before treating rank as an optimization target.
2. **'Low effective rank means duplicate heads.'** False if directional rank/cosine are healthy; it may just be energy imbalance.
3. **'The attention computation is where collapse happens.'** Context-vs-residual rank tells us whether W_O is actually the bottleneck.
4. **'A large residual head is an important head.'** Exact ΔCE vs RMS tests that directly.
5. **'All 16 heads are needed because the model was trained dense.'** The ablations/head-count curve test this rather than assuming it.
6. **'Keeping the biggest heads is enough.'** Top-energy vs random same-count subsets tests whether magnitude contains useful pruning information.
7. **'Effective rank should be directly maximized.'** Only justified if low directional rank associates with worse CE; raw rank alone also penalizes legitimate specialization.
