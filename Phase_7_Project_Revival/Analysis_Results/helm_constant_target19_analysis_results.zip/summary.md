# HELM constant-target-19 router analysis

Latest checkpoint: **checkpoint-006000.pt**

## Latest router behavior

| layer | actual K | target | MAE | mean p | p>.5 | p in [.45,.55] | unique masks |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 18.00 | 19 | 1.00 | 0.481 | 0.375 | 0.300 | 1 |
| 1 | 19.05 | 19 | 0.42 | 0.503 | 0.325 | 0.708 | 7 |
| 2 | 19.00 | 19 | 0.00 | 0.632 | 0.417 | 0.667 | 1 |
| 3 | 19.11 | 19 | 0.27 | 0.593 | 0.376 | 0.750 | 8 |
| 4 | 19.14 | 19 | 0.23 | 0.627 | 0.371 | 0.708 | 9 |
| 5 | 19.86 | 19 | 0.86 | 0.559 | 0.314 | 0.551 | 4 |
| 6 | 19.11 | 19 | 0.39 | 0.425 | 0.368 | 0.535 | 6 |
| 7 | 18.67 | 19 | 0.33 | 0.575 | 0.417 | 0.348 | 2 |
| 8 | 19.03 | 19 | 0.03 | 0.581 | 0.456 | 0.565 | 2 |
| 9 | 19.33 | 19 | 0.42 | 0.295 | 0.400 | 0.482 | 8 |
| 10 | 19.31 | 19 | 0.38 | 0.357 | 0.431 | 0.309 | 5 |
| 11 | 19.64 | 19 | 0.77 | 0.317 | 0.402 | 0.445 | 9 |

## Checkpoint-to-checkpoint router stability

| A | B | layer | sigmoid corr | mean |Δp| | hard-mask agreement |
|---|---|---:|---:|---:|---:|
| checkpoint-000500.pt | checkpoint-001000.pt | 0 | 0.9570 | 0.04056 | 0.9180 |
| checkpoint-000500.pt | checkpoint-001000.pt | 5 | 0.8344 | 0.03222 | 0.8535 |
| checkpoint-000500.pt | checkpoint-001000.pt | 11 | 0.9169 | 0.02489 | 0.9219 |
| checkpoint-000500.pt | checkpoint-001000.pt | ALL | 0.8697 | 0.03209 | 0.8873 |
| checkpoint-001000.pt | checkpoint-002000.pt | 0 | 0.9497 | 0.02271 | 0.9596 |
| checkpoint-001000.pt | checkpoint-002000.pt | 5 | 0.9954 | 0.00815 | 0.8158 |
| checkpoint-001000.pt | checkpoint-002000.pt | 11 | 0.6675 | 0.05271 | 0.9408 |
| checkpoint-001000.pt | checkpoint-002000.pt | ALL | 0.8650 | 0.03072 | 0.9039 |
| checkpoint-002000.pt | checkpoint-004000.pt | 0 | 0.9876 | 0.01935 | 1.0000 |
| checkpoint-002000.pt | checkpoint-004000.pt | 5 | 0.8847 | 0.03177 | 0.8451 |
| checkpoint-002000.pt | checkpoint-004000.pt | 11 | 0.4868 | 0.09108 | 0.9570 |
| checkpoint-002000.pt | checkpoint-004000.pt | ALL | 0.8166 | 0.05036 | 0.9355 |
| checkpoint-004000.pt | checkpoint-006000.pt | 0 | 0.9948 | 0.02441 | 0.9583 |
| checkpoint-004000.pt | checkpoint-006000.pt | 5 | 0.9524 | 0.03209 | 0.8991 |
| checkpoint-004000.pt | checkpoint-006000.pt | 11 | 0.9195 | 0.12910 | 0.9642 |
| checkpoint-004000.pt | checkpoint-006000.pt | ALL | 0.9267 | 0.05391 | 0.9509 |