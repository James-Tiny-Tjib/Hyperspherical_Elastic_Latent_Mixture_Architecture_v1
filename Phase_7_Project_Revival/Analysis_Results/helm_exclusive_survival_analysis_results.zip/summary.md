# Exclusive-attention survival: HELM_7e vs Dense-32

## Layer survival

| model | L | self mass | pre RMS | post RMS | energy survival | removed | rho(self,removed) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Dense-32 | 0 | 0.0180 | 0.052074 | 0.040474 | 0.6440 | 0.3560 | 0.802 |
| Dense-32 | 1 | 0.0104 | 0.041608 | 0.033832 | 0.7159 | 0.2841 | 0.453 |
| Dense-32 | 2 | 0.0332 | 0.027078 | 0.020644 | 0.6395 | 0.3605 | -0.033 |
| Dense-32 | 3 | 0.0686 | 0.023119 | 0.018812 | 0.7169 | 0.2831 | 0.280 |
| Dense-32 | 4 | 0.2514 | 0.022582 | 0.014831 | 0.4684 | 0.5316 | 0.288 |
| Dense-32 | 5 | 0.1122 | 0.020380 | 0.015422 | 0.5862 | 0.4138 | 0.166 |
| Dense-32 | 6 | 0.4507 | 0.021742 | 0.010464 | 0.2959 | 0.7041 | 0.737 |
| Dense-32 | 7 | 0.3592 | 0.019274 | 0.011377 | 0.3715 | 0.6285 | 0.521 |
| Dense-32 | 8 | 0.2499 | 0.023024 | 0.014467 | 0.4672 | 0.5328 | 0.811 |
| Dense-32 | 9 | 0.2302 | 0.021728 | 0.012690 | 0.4489 | 0.5511 | 0.835 |
| Dense-32 | 10 | 0.2772 | 0.021166 | 0.011835 | 0.3841 | 0.6159 | 0.876 |
| Dense-32 | 11 | 0.3879 | 0.022308 | 0.010876 | 0.2544 | 0.7456 | 0.777 |
| HELM_7e | 0 | 0.0044 | 0.047004 | 0.032720 | 0.5028 | 0.4972 | 0.569 |
| HELM_7e | 1 | 0.0353 | 0.037998 | 0.024075 | 0.4604 | 0.5396 | 0.582 |
| HELM_7e | 2 | 0.0748 | 0.027101 | 0.014513 | 0.3295 | 0.6705 | 0.436 |
| HELM_7e | 3 | 0.1777 | 0.031274 | 0.016512 | 0.3582 | 0.6418 | 0.400 |
| HELM_7e | 4 | 0.2340 | 0.024929 | 0.014600 | 0.4518 | 0.5482 | 0.580 |
| HELM_7e | 5 | 0.5797 | 0.029252 | 0.011529 | 0.2475 | 0.7525 | 0.947 |
| HELM_7e | 6 | 0.5434 | 0.027769 | 0.010658 | 0.2828 | 0.7172 | 0.923 |
| HELM_7e | 7 | 0.6262 | 0.029464 | 0.010097 | 0.2087 | 0.7913 | 0.918 |
| HELM_7e | 8 | 0.6270 | 0.028501 | 0.009870 | 0.2266 | 0.7734 | 0.932 |
| HELM_7e | 9 | 0.6687 | 0.030073 | 0.008551 | 0.1681 | 0.8319 | 0.959 |
| HELM_7e | 10 | 0.5454 | 0.026248 | 0.009259 | 0.2148 | 0.7852 | 0.949 |
| HELM_7e | 11 | 0.5862 | 0.026671 | 0.009421 | 0.1598 | 0.8402 | 0.922 |

## Lambda counterfactual

| model | lambda | CE | delta vs native lambda=1 |
|---|---:|---:|---:|
| HELM_7e | 1.00 | 3.464541 | +0.000000 |
| HELM_7e | 0.75 | 3.892561 | +0.428020 |
| HELM_7e | 0.50 | 4.812343 | +1.347802 |
| HELM_7e | 0.25 | 5.596637 | +2.132096 |
| HELM_7e | 0.00 | 6.135606 | +2.671065 |
| Dense-32 | 1.00 | 3.441433 | +0.000000 |
| Dense-32 | 0.75 | 3.768141 | +0.326708 |
| Dense-32 | 0.50 | 4.662553 | +1.221120 |
| Dense-32 | 0.25 | 5.690588 | +2.249155 |
| Dense-32 | 0.00 | 6.470789 | +3.029355 |

## Interpretation

- If 7e loses substantially more pre-context energy than Dense-32, the prior magnitude deficit is mechanistically upstream of W_O.
- If self-attention strongly predicts removed energy specifically in 7e, that supports the self-focus × exclusive-projection mechanism.
- If weakening lambda immediately improves 7e more than Dense-32, that strengthens the mechanism, but it remains an OOD checkpoint probe.
- The from-scratch paired no-exclusive runs are the causal test.
- `projection_identity_relative_error` should be near zero; a large value indicates a bug/numerical issue in the decomposition.