# HELM_32_random analysis

## CE modes

| mode | CE | std across random mask trials |
|---|---:|---:|
| random_sparse | 3.700218 | 0.001843 |
| forced_dense_same_bank | 3.697877 | 0.000000 |
| permanent_only | 3.832453 | 0.000000 |

The critical quantity is `forced_dense_same_bank` vs native Dense-32 under the same diagnostic protocol.
If this randomly/sparsely trained bank remains much worse when all 32 heads are turned on, sparse exposure itself damages bank quality.

## Random A_h/I_h negative control

- Layer 0: mean random A-I gap=+0.000419; fraction positive=0.667
- Layer 5: mean random A-I gap=-0.000004; fraction positive=0.542
- Layer 11: mean random A-I gap=+0.000115; fraction positive=0.542
- Expected result: gaps fluctuate around zero because activation was randomly assigned.