# HELM constant-K Top-K analysis

Configured total K = **19** on every example.

## CE modes

| mode | CE | std |
|---|---:|---:|
| learned_routed | 3.675872 | 0.000000 |
| forced_dense_all32 | 3.742294 | 0.000000 |
| permanent_only | 5.311887 | 0.000000 |
| random_same_count | 4.294245 | 0.011819 |

Interpretation:
- `learned_routed` vs `random_same_count` isolates learned IDENTITY selection at identical K.
- Compare this model's validation/diagnostic CE against 7c to test whether adaptive CARDINALITY matters.

## Constant-K verification

| layer | configured | mean | min | max | exact? |
|---:|---:|---:|---:|---:|---:|
| 0 | 19 | 19.00 | 19 | 19 | 1 |
| 1 | 19 | 19.00 | 19 | 19 | 1 |
| 2 | 19 | 19.00 | 19 | 19 | 1 |
| 3 | 19 | 19.00 | 19 | 19 | 1 |
| 4 | 19 | 19.00 | 19 | 19 | 1 |
| 5 | 19 | 19.00 | 19 | 19 | 1 |
| 6 | 19 | 19.00 | 19 | 19 | 1 |
| 7 | 19 | 19.00 | 19 | 19 | 1 |
| 8 | 19 | 19.00 | 19 | 19 | 1 |
| 9 | 19 | 19.00 | 19 | 19 | 1 |
| 10 | 19 | 19.00 | 19 | 19 | 1 |
| 11 | 19 | 19.00 | 19 | 19 | 1 |

## A_h / I_h specialization

- Layer 0: mean A-I gap=+nan; fraction positive=nan
- Layer 5: mean A-I gap=+0.000917; fraction positive=1.000
- Layer 11: mean A-I gap=+0.002550; fraction positive=0.857