# HELM_7c head-bank assumption audit

Checkpoint: **checkpoint-006500.pt**  
Heads: **32 total = 8 permanent + 24 elastic**  
This audit separates **raw rank** (direction + magnitude) from **directional rank** (direction only), and separates the full **potential** head bank from the actually **executed** routed bank.

## 1. CE controls

|Mode|CE|Δ vs routed|
|---|---:|---:|
|routed|3.492086|+0.000000|
|dense|3.489403|-0.002683|
|random_same_count|3.793083|+0.300997|
|permanent_only|4.934040|+1.441954|

Interpretation: **random-same-count** tests whether identity matters at fixed compute; **dense** asks whether this routed-trained checkpoint benefits from turning every head on; **permanent-only** tests whether the elastic bank is genuinely needed.

## 2. Router sanity

|Layer|Actual K|Target K|MAE|rho(target,actual)|sigmoid mean|near .5|
|---:|---:|---:|---:|---:|---:|---:|
|0|15.50|18.50|3.88|0.855|0.433|23.2%|
|1|19.38|18.50|2.50|0.909|0.466|43.2%|
|2|18.75|18.50|2.38|0.916|0.461|21.6%|
|3|19.44|18.50|2.44|0.931|0.469|19.5%|
|4|19.25|18.50|2.50|0.920|0.479|24.0%|
|5|19.94|18.50|2.81|0.915|0.433|19.5%|
|6|19.94|18.50|2.44|0.893|0.396|31.5%|
|7|19.56|18.50|2.69|0.957|0.452|17.7%|
|8|20.12|18.50|3.38|0.850|0.460|22.1%|
|9|19.56|18.50|3.94|0.726|0.407|28.1%|
|10|20.75|18.50|3.12|0.908|0.426|22.4%|
|11|21.06|18.50|3.56|0.846|0.427|30.2%|

## 3. The key comparison: POTENTIAL residual rank

Potential means **all heads are recomputed before masking**. This is the closest apples-to-apples comparison to the dense-16 head-bank audit.

|Layer|All raw|All dir|Permanent raw|Permanent dir|Elastic raw|Elastic dir|Elastic mean |cos||
|---:|---:|---:|---:|---:|---:|---:|---:|
|0|5.73/32|20.53/32|3.50/8|4.12/8|5.26/24|19.85/24|0.103|
|1|8.46/32|27.57/32|5.06/8|6.52/8|5.43/24|22.22/24|0.056|
|2|14.50/32|28.37/32|4.31/8|6.71/8|15.68/24|22.73/24|0.046|
|3|12.67/32|31.74/32|5.34/8|7.94/8|7.51/24|23.87/24|0.013|
|4|15.57/32|31.61/32|6.63/8|7.92/8|9.29/24|23.88/24|0.013|
|5|12.26/32|31.68/32|5.44/8|7.82/8|10.41/24|23.98/24|0.006|
|6|11.67/32|31.87/32|4.73/8|7.95/8|9.29/24|23.97/24|0.006|
|7|13.28/32|31.65/32|6.60/8|7.75/8|6.97/24|23.96/24|0.007|
|8|12.05/32|31.54/32|6.03/8|7.63/8|6.06/24|23.96/24|0.006|
|9|14.05/32|31.71/32|6.69/8|7.88/8|7.50/24|23.95/24|0.006|
|10|14.90/32|31.00/32|6.84/8|7.23/8|8.35/24|23.96/24|0.007|
|11|12.92/32|31.62/32|3.39/8|7.91/8|11.79/24|23.90/24|0.011|

### How to interpret this table
- **low elastic raw + high elastic directional rank** → the elastic heads are mostly different directions but have unequal strength. That is much closer to what the dense-16 baseline does and is **not** evidence for duplicate-head collapse.
- **low elastic raw + low elastic directional rank** → real directional redundancy exists inside the elastic candidate bank. That would be a stronger reason to consider a diversity objective.
- **context directional rank high but residual directional rank low** → attention contexts are diverse, but W_O aligns/compresses how they write back to the residual stream.

## 4. Pre-W_O vs post-W_O directional rank (POTENTIAL elastic bank)

|Layer|Context dir rank|Residual dir rank|Context mean |cos||Residual mean |cos||
|---:|---:|---:|---:|---:|
|0|23.56/24|19.85/24|0.027|0.103|
|1|23.65/24|22.22/24|0.026|0.056|
|2|23.69/24|22.73/24|0.025|0.046|
|3|23.86/24|23.87/24|0.016|0.013|
|4|23.85/24|23.88/24|0.017|0.013|
|5|23.94/24|23.98/24|0.010|0.006|
|6|23.87/24|23.97/24|0.013|0.006|
|7|23.93/24|23.96/24|0.012|0.007|
|8|23.93/24|23.96/24|0.011|0.006|
|9|23.91/24|23.95/24|0.012|0.006|
|10|23.93/24|23.96/24|0.012|0.007|
|11|23.80/24|23.90/24|0.021|0.011|

## 5. Potential vs executed elastic bank

Potential asks **are the candidates diverse?** Executed asks **what does hard routing actually expose across these examples?** A large potential→executed drop can be a routing selection effect rather than a representational collapse.

|Layer|Potential raw|Potential dir|Executed raw|Executed dir|
|---:|---:|---:|---:|---:|
|0|5.26/24|19.85/24|2.87/24|7.36/24|
|1|5.43/24|22.22/24|3.24/24|15.87/24|
|2|15.68/24|22.73/24|9.79/24|16.26/24|
|3|7.51/24|23.87/24|5.25/24|16.97/24|
|4|9.29/24|23.88/24|6.31/24|15.95/24|
|5|10.41/24|23.98/24|8.29/24|16.98/24|
|6|9.29/24|23.97/24|7.11/24|14.98/24|
|7|6.97/24|23.96/24|6.04/24|16.97/24|
|8|6.06/24|23.96/24|5.55/24|15.96/24|
|9|7.50/24|23.95/24|6.53/24|14.97/24|
|10|8.35/24|23.96/24|7.16/24|15.96/24|
|11|11.79/24|23.90/24|9.40/24|16.92/24|

## 6. Does usage predict strength?

- L00: rho(activation, **potential** residual RMS)=0.682; rho(activation, **executed** residual RMS)=0.986.
- L01: rho(activation, **potential** residual RMS)=0.626; rho(activation, **executed** residual RMS)=0.909.
- L02: rho(activation, **potential** residual RMS)=0.742; rho(activation, **executed** residual RMS)=0.967.
- L03: rho(activation, **potential** residual RMS)=0.841; rho(activation, **executed** residual RMS)=0.979.
- L04: rho(activation, **potential** residual RMS)=0.775; rho(activation, **executed** residual RMS)=0.973.
- L05: rho(activation, **potential** residual RMS)=0.819; rho(activation, **executed** residual RMS)=0.969.
- L06: rho(activation, **potential** residual RMS)=0.854; rho(activation, **executed** residual RMS)=0.984.
- L07: rho(activation, **potential** residual RMS)=0.668; rho(activation, **executed** residual RMS)=0.982.
- L08: rho(activation, **potential** residual RMS)=0.838; rho(activation, **executed** residual RMS)=0.964.
- L09: rho(activation, **potential** residual RMS)=0.758; rho(activation, **executed** residual RMS)=0.963.
- L10: rho(activation, **potential** residual RMS)=0.872; rho(activation, **executed** residual RMS)=0.976.
- L11: rho(activation, **potential** residual RMS)=0.626; rho(activation, **executed** residual RMS)=0.909.
This correlation is descriptive, not causal. 7d showed why increasing gradients to OFF heads without forward exposure is not a valid way to infer causality.

## 7. Exact routed single-head ablation

Skipped. Re-run with `--exact-ablation` if needed.

## 8. Assumptions this script is explicitly checking

1. **'7c has low rank, therefore its heads are redundant.'** Raw rank alone cannot establish that.
2. **'Unequal head energy is a pathology.'** Dense-16 showed substantial raw-rank loss despite near-maximal directional rank.
3. **'The router causes any observed rank loss.'** Potential vs executed rank separates candidate-bank geometry from selection geometry.
4. **'Attention itself creates the redundancy.'** Context vs residual rank tests whether W_O is the stronger source of alignment.
5. **'Frequently selected heads are inherently better heads.'** Usage-vs-strength and optional exact ablation test association without assuming causality.
6. **'All 32 would be better if turned on.'** Routed-vs-forced-dense CE tests that checkpoint-level claim directly.
