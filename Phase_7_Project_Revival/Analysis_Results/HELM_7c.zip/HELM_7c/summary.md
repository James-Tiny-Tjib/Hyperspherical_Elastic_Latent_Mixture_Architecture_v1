# HELM_7c Head Dynamics Analysis
Checkpoint: `JamesResearch1216/HELM_7c/checkpoint-006500.pt`
Examples: 16, sequence length: 1024, batch size: 2

## 1. CE mode comparisons
- **routed**: 3.532994
- **forced_dense**: 3.525806
- **permanent_only**: 4.961676
- **random_same_count_mean**: 3.809621
- **random_same_count_std**: 0.011730
- **utility subset routed CE**: 3.559464
- **utility subset forced-dense CE**: 3.561262
- **first-order oracle same-count CE**: 3.585152

Interpretation:
- Forced-dense is better than routed: the current sparse decisions are removing useful attention contribution.
- Routed beats random-same-count: head identity selection contains useful information beyond cardinality.
- Permanent-only gap vs routed: +1.428683 CE.

## 2. Router/cardinality summary
- L00: actual=18.31, target=19.62, MAE=2.94, rho(easy,count)=-0.899, dynamic_heads=95.8%, mask_hamming=0.365, sat=0.0%, STE'=0.2174, Wnorm=6.57
- L01: actual=19.94, target=19.62, MAE=1.94, rho(easy,count)=-0.931, dynamic_heads=91.7%, mask_hamming=0.412, sat=12.0%, STE'=0.1901, Wnorm=4.65
- L02: actual=19.31, target=19.62, MAE=2.44, rho(easy,count)=-0.931, dynamic_heads=83.3%, mask_hamming=0.345, sat=26.8%, STE'=0.1559, Wnorm=5.38
- L03: actual=20.69, target=19.62, MAE=2.06, rho(easy,count)=-0.952, dynamic_heads=87.5%, mask_hamming=0.371, sat=33.6%, STE'=0.1407, Wnorm=5.60
- L04: actual=19.94, target=19.62, MAE=2.06, rho(easy,count)=-0.946, dynamic_heads=91.7%, mask_hamming=0.349, sat=28.6%, STE'=0.1477, Wnorm=6.84
- L05: actual=21.38, target=19.62, MAE=3.00, rho(easy,count)=-0.908, dynamic_heads=91.7%, mask_hamming=0.310, sat=27.6%, STE'=0.1499, Wnorm=6.88
- L06: actual=21.06, target=19.62, MAE=2.31, rho(easy,count)=-0.949, dynamic_heads=83.3%, mask_hamming=0.325, sat=21.1%, STE'=0.1714, Wnorm=7.34
- L07: actual=20.69, target=19.62, MAE=2.56, rho(easy,count)=-0.927, dynamic_heads=83.3%, mask_hamming=0.328, sat=25.5%, STE'=0.1471, Wnorm=8.44
- L08: actual=20.69, target=19.62, MAE=2.56, rho(easy,count)=-0.880, dynamic_heads=79.2%, mask_hamming=0.320, sat=20.1%, STE'=0.1522, Wnorm=8.39
- L09: actual=21.06, target=19.62, MAE=2.56, rho(easy,count)=-0.921, dynamic_heads=79.2%, mask_hamming=0.314, sat=22.1%, STE'=0.1680, Wnorm=7.61
- L10: actual=21.56, target=19.62, MAE=2.81, rho(easy,count)=-0.941, dynamic_heads=79.2%, mask_hamming=0.298, sat=25.5%, STE'=0.1513, Wnorm=8.67
- L11: actual=21.69, target=19.62, MAE=3.44, rho(easy,count)=-0.849, dynamic_heads=70.8%, mask_hamming=0.295, sat=24.5%, STE'=0.1492, Wnorm=8.30

## 3. Router vs CE head utility
- L00: rho(logit, |dCE/dgate|)=0.155, top-k overlap=0.754, selected/inactive utility=1.674
- L01: rho(logit, |dCE/dgate|)=0.271, top-k overlap=0.754, selected/inactive utility=3.399
- L02: rho(logit, |dCE/dgate|)=0.466, top-k overlap=0.698, selected/inactive utility=3.183
- L03: rho(logit, |dCE/dgate|)=0.529, top-k overlap=0.842, selected/inactive utility=6.261
- L04: rho(logit, |dCE/dgate|)=0.533, top-k overlap=0.706, selected/inactive utility=5.065
- L05: rho(logit, |dCE/dgate|)=0.431, top-k overlap=0.801, selected/inactive utility=5.149
- L06: rho(logit, |dCE/dgate|)=0.493, top-k overlap=0.820, selected/inactive utility=7.982
- L07: rho(logit, |dCE/dgate|)=0.555, top-k overlap=0.798, selected/inactive utility=11.037
- L08: rho(logit, |dCE/dgate|)=0.580, top-k overlap=0.870, selected/inactive utility=17.016
- L09: rho(logit, |dCE/dgate|)=0.502, top-k overlap=0.859, selected/inactive utility=32.594
- L10: rho(logit, |dCE/dgate|)=0.567, top-k overlap=0.834, selected/inactive utility=15.945
- L11: rho(logit, |dCE/dgate|)=0.422, top-k overlap=0.879, selected/inactive utility=34.365

The approximate utility oracle does not materially beat HELM on the utility subset; redundancy/mixing may matter more than selector capacity.

## 4. Functional redundancy
- L00: functional entropy-rank=5.75/32, participation-rank=2.99/32, mean |functional cosine|=0.172, frac |cos|>.8=0.0%, mean |parameter cosine|=0.002
  - Highest functional-similarity pairs: [(2, 24, 0.6975582257754143), (7, 13, 0.6630625050887113), (2, 7, 0.653596154690186), (2, 13, 0.6501878171668213), (7, 24, 0.6389222287375721), (0, 2, 0.6315936375903095), (13, 24, 0.6245941253609523), (6, 7, 0.6090271455204548)]
- L05: functional entropy-rank=12.05/32, participation-rank=7.89/32, mean |functional cosine|=0.011, frac |cos|>.8=0.0%, mean |parameter cosine|=0.005
  - Highest functional-similarity pairs: [(3, 4, 0.2738294282595154), (0, 3, -0.26048850162822984), (0, 8, 0.1576453690551683), (3, 7, 0.1539813234635113), (3, 8, -0.1107721328548897), (5, 28, 0.10722244439262912), (3, 14, 0.10484972911749471), (6, 20, 0.10284742960657241)]
- L11: functional entropy-rank=13.22/32, participation-rank=7.27/32, mean |functional cosine|=0.013, frac |cos|>.8=0.0%, mean |parameter cosine|=0.004
  - Highest functional-similarity pairs: [(5, 6, 0.3012120395586952), (6, 13, 0.26578867044540055), (6, 14, 0.1675197947772091), (6, 19, 0.14444333581032687), (5, 13, 0.13884056318005816), (6, 18, 0.11422383066674188), (8, 14, 0.11067792659423661), (13, 14, 0.10970953040819292)]

### How to use this for the proposed nonlinear 1024→2048 refinement
- If functional effective rank is low / output similarities are high even though parameter similarities are modest, the expanded attention head bank is producing redundant residual features. That is evidence worth testing a nonlinear head-refinement/expansion ablation.
- If head outputs are diverse but router-logit/utility alignment is poor and random-same-count is competitive, the attention expansion is probably not the first bottleneck; the selector is.
- If head outputs are diverse and router selection is good, but dense still beats routed, the 0/1 mixture may be too coarse; that is the strongest case for testing weighted active-head contributions next.
