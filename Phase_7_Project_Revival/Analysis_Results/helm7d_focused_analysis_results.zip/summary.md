# HELM_7d Focused Diagnostic
Checkpoint: `JamesResearch1216/HELM_7d/checkpoint-006500.pt`
Examples: 8, sequence length: 1024, batch size: 2

## 1. CE comparisons
- **routed**: 3.639678
- **forced_dense**: 3.786926
- **permanent_only**: 5.165209
- **random_same_count_mean**: 4.025017
- **random_same_count_std**: 0.075933
- Routed still beats random-same-count: head identity selection remains meaningful.
- Forced-dense minus routed CE: +0.147248

## 2. Router/cardinality and 7d backward rescue
- Mean model count loss on diagnostic batches: 0.029442
- L00: actual=18.12, target=18.25, error=-0.12, MAE=3.12, count_loss=0.0127, elastic_on=42.2%, sigmoid_mean=0.451, <.45=37.0%, .45-.55=51.6%, >.55=11.5%, off-backward=0.390, off>.45=36.0%, STE'=0.238, Wnorm=3.44
- L01: actual=17.00, target=18.25, error=-1.25, MAE=3.25, count_loss=0.0174, elastic_on=37.5%, sigmoid_mean=0.473, <.45=26.6%, .45-.55=71.4%, >.55=2.1%, off-backward=0.444, off>.45=57.5%, STE'=0.246, Wnorm=2.46
- L02: actual=17.12, target=18.25, error=-1.12, MAE=3.12, count_loss=0.0101, elastic_on=38.0%, sigmoid_mean=0.412, <.45=43.2%, .45-.55=34.4%, >.55=22.4%, off-backward=0.302, off>.45=30.3%, STE'=0.202, Wnorm=3.70
- L03: actual=18.50, target=18.25, error=+0.25, MAE=2.25, count_loss=0.0063, elastic_on=43.8%, sigmoid_mean=0.511, <.45=16.1%, .45-.55=63.5%, >.55=20.3%, off-backward=0.421, off>.45=71.3%, STE'=0.218, Wnorm=2.51
- L04: actual=18.12, target=18.25, error=-0.12, MAE=2.38, count_loss=0.0086, elastic_on=42.2%, sigmoid_mean=0.483, <.45=33.9%, .45-.55=38.0%, >.55=28.1%, off-backward=0.357, off>.45=41.4%, STE'=0.206, Wnorm=4.05
- L05: actual=18.50, target=18.25, error=+0.25, MAE=4.00, count_loss=0.0187, elastic_on=43.8%, sigmoid_mean=0.536, <.45=16.1%, .45-.55=63.0%, >.55=20.8%, off-backward=0.446, off>.45=71.3%, STE'=0.220, Wnorm=2.57
- L06: actual=19.00, target=18.25, error=+0.75, MAE=4.25, count_loss=0.0200, elastic_on=45.8%, sigmoid_mean=0.536, <.45=9.4%, .45-.55=70.8%, >.55=19.8%, off-backward=0.468, off>.45=82.7%, STE'=0.230, Wnorm=2.83
- L07: actual=20.00, target=18.25, error=+1.75, MAE=4.25, count_loss=0.0254, elastic_on=50.0%, sigmoid_mean=0.531, <.45=17.7%, .45-.55=60.4%, >.55=21.9%, off-backward=0.442, off>.45=64.6%, STE'=0.226, Wnorm=3.33
- L08: actual=21.12, target=18.25, error=+2.88, MAE=5.62, count_loss=0.0370, elastic_on=54.7%, sigmoid_mean=0.539, <.45=1.0%, .45-.55=83.3%, >.55=15.6%, off-backward=0.494, off>.45=97.7%, STE'=0.237, Wnorm=2.23
- L09: actual=22.00, target=18.25, error=+3.75, MAE=5.75, count_loss=0.0482, elastic_on=58.3%, sigmoid_mean=0.555, <.45=0.0%, .45-.55=80.2%, >.55=19.8%, off-backward=0.497, off>.45=100.0%, STE'=0.230, Wnorm=2.76
- L10: actual=23.50, target=18.25, error=+5.25, MAE=7.00, count_loss=0.0736, elastic_on=64.6%, sigmoid_mean=0.548, <.45=1.0%, .45-.55=83.9%, >.55=15.1%, off-backward=0.496, off>.45=97.1%, STE'=0.232, Wnorm=2.60
- L11: actual=23.50, target=18.25, error=+5.25, MAE=7.75, count_loss=0.0755, elastic_on=64.6%, sigmoid_mean=0.579, <.45=0.0%, .45-.55=76.0%, >.55=24.0%, off-backward=0.500, off>.45=100.0%, STE'=0.219, Wnorm=2.75

### What matters for the 7d failure
- Positive count error together with sigmoid mass shifting above 0.5 means the router is activating more elastic heads than its easiness target requests.
- A high `off-backward` value means heads that are nominally OFF are still receiving a large fraction of full CE training. If this approaches ~0.5, the 7d rescue is not a weak rescue anymore; it is nearly half-strength dense training.
- The key question is whether that extra training actually broadened the elastic head bank. That is what the effective-rank/RMS section tests.

## 3. Head-bank dynamics
- L00: all-rank=8.18/32, perm-rank=3.22/8, elastic-rank=7.48/24, perm_RMS=0.031276, elastic_RMS=0.068623, perm/elastic=0.46x, rho(activation,RMS)=0.612
- L05: all-rank=11.58/32, perm-rank=6.30/8, elastic-rank=8.84/24, perm_RMS=0.010383, elastic_RMS=0.015866, perm/elastic=0.65x, rho(activation,RMS)=-0.531
- L11: all-rank=1.98/32, perm-rank=5.89/8, elastic-rank=1.91/24, perm_RMS=0.003524, elastic_RMS=0.015786, perm/elastic=0.22x, rho(activation,RMS)=-0.406

### How to interpret 7d vs 7c
- If elastic effective rank rises and permanent/elastic RMS imbalance falls, 7d successfully reduced starvation even if routing became unstable.
- If elastic rank/RMS barely improve but router counts shift upward, the rescue path mostly destabilized routing without fixing the head bank.
- If `rho(activation,RMS)` falls substantially from 7c, that supports the idea that previously rare heads are catching up. If it remains very high, the rich-get-richer pattern persists.
- If CE becomes noisy while counts overshoot, the most likely interpretation is that CE increasingly rewards newly-trained elastic heads while the count loss pushes their logits back down, creating competing objectives around the threshold.
