# HELM_7c Head Dynamics Analysis
Checkpoint: `JamesResearch1216/HELM_7c/checkpoint-006500.pt`
Examples: 8, sequence length: 1024, batch size: 2

## 1. CE mode comparisons
- **routed**: 3.558317
- **forced_dense**: 3.560983
- **permanent_only**: 4.929749
- **random_same_count_mean**: 3.895233
- **random_same_count_std**: 0.037265
- **utility subset routed CE**: 3.558317
- **utility subset forced-dense CE**: 3.562747
- **signed first-order oracle same-count CE**: 3.716851

Interpretation:
- Routed is better than forced-dense: simply restoring every head does not improve this checkpoint.
- Routed beats random-same-count: head identity selection contains useful information beyond cardinality.
- Permanent-only gap vs routed: +1.371432 CE.

## 2. Router/cardinality summary
- L00: actual=18.12, target=18.25, MAE=2.12, rho(easy,count)=-0.909, dynamic_heads=95.8%, mask_hamming=0.410, sat=0.0%, STE'=0.2063, Wnorm=6.57
- L01: actual=18.88, target=18.25, MAE=1.88, rho(easy,count)=-0.913, dynamic_heads=91.7%, mask_hamming=0.415, sat=15.6%, STE'=0.1769, Wnorm=4.65
- L02: actual=18.25, target=18.25, MAE=2.25, rho(easy,count)=-0.903, dynamic_heads=83.3%, mask_hamming=0.359, sat=36.5%, STE'=0.1412, Wnorm=5.38
- L03: actual=19.75, target=18.25, MAE=2.25, rho(easy,count)=-0.907, dynamic_heads=83.3%, mask_hamming=0.375, sat=43.2%, STE'=0.1241, Wnorm=5.60
- L04: actual=18.50, target=18.25, MAE=2.25, rho(easy,count)=-0.934, dynamic_heads=83.3%, mask_hamming=0.352, sat=35.9%, STE'=0.1388, Wnorm=6.84
- L05: actual=21.00, target=18.25, MAE=4.25, rho(easy,count)=-0.913, dynamic_heads=58.3%, mask_hamming=0.253, sat=31.8%, STE'=0.1424, Wnorm=6.88
- L06: actual=20.12, target=18.25, MAE=2.88, rho(easy,count)=-0.934, dynamic_heads=79.2%, mask_hamming=0.316, sat=30.2%, STE'=0.1559, Wnorm=7.34
- L07: actual=19.25, target=18.25, MAE=2.50, rho(easy,count)=-0.854, dynamic_heads=87.5%, mask_hamming=0.336, sat=35.9%, STE'=0.1375, Wnorm=8.44
- L08: actual=19.62, target=18.25, MAE=2.88, rho(easy,count)=-0.854, dynamic_heads=79.2%, mask_hamming=0.322, sat=29.7%, STE'=0.1354, Wnorm=8.39
- L09: actual=19.75, target=18.25, MAE=2.50, rho(easy,count)=-0.847, dynamic_heads=79.2%, mask_hamming=0.331, sat=35.4%, STE'=0.1433, Wnorm=7.61
- L10: actual=20.50, target=18.25, MAE=3.25, rho(easy,count)=-0.913, dynamic_heads=70.8%, mask_hamming=0.284, sat=35.4%, STE'=0.1386, Wnorm=8.67
- L11: actual=20.38, target=18.25, MAE=3.12, rho(easy,count)=-0.771, dynamic_heads=70.8%, mask_hamming=0.296, sat=35.9%, STE'=0.1283, Wnorm=8.30

## 3. Router vs CE head utility
- L00: rho(logit, signed CE utility)=0.178, top-k overlap=0.698, selected-inactive signed utility=0.000018, selected/inactive |gradient|=1.664, positive utility fraction=0.536
- L01: rho(logit, signed CE utility)=0.122, top-k overlap=0.594, selected-inactive signed utility=0.000190, selected/inactive |gradient|=3.297, positive utility fraction=0.453
- L02: rho(logit, signed CE utility)=0.031, top-k overlap=0.573, selected-inactive signed utility=0.000046, selected/inactive |gradient|=3.114, positive utility fraction=0.422
- L03: rho(logit, signed CE utility)=0.022, top-k overlap=0.634, selected-inactive signed utility=-0.000012, selected/inactive |gradient|=6.515, positive utility fraction=0.401
- L04: rho(logit, signed CE utility)=0.004, top-k overlap=0.569, selected-inactive signed utility=0.000408, selected/inactive |gradient|=5.287, positive utility fraction=0.401
- L05: rho(logit, signed CE utility)=0.047, top-k overlap=0.620, selected-inactive signed utility=0.000140, selected/inactive |gradient|=4.988, positive utility fraction=0.484
- L06: rho(logit, signed CE utility)=0.059, top-k overlap=0.551, selected-inactive signed utility=-0.000023, selected/inactive |gradient|=7.909, positive utility fraction=0.453
- L07: rho(logit, signed CE utility)=0.042, top-k overlap=0.621, selected-inactive signed utility=0.000175, selected/inactive |gradient|=11.320, positive utility fraction=0.448
- L08: rho(logit, signed CE utility)=0.097, top-k overlap=0.703, selected-inactive signed utility=0.000510, selected/inactive |gradient|=16.294, positive utility fraction=0.484
- L09: rho(logit, signed CE utility)=-0.073, top-k overlap=0.588, selected-inactive signed utility=0.000037, selected/inactive |gradient|=19.727, positive utility fraction=0.490
- L10: rho(logit, signed CE utility)=-0.029, top-k overlap=0.604, selected-inactive signed utility=0.000345, selected/inactive |gradient|=16.388, positive utility fraction=0.490
- L11: rho(logit, signed CE utility)=0.029, top-k overlap=0.594, selected-inactive signed utility=0.000638, selected/inactive |gradient|=33.740, positive utility fraction=0.526

HELM routing beats the signed first-order oracle. The local gradient approximation is not sufficient to improve the selected set, so exact intervention results should be trusted more heavily.

## 4. Functional redundancy
- L00:
  - all heads entropy-rank=5.75/32, participation-rank=2.99/32
  - permanent heads entropy-rank=3.54/8, participation-rank=2.45/8
  - elastic heads entropy-rank=5.53/24, participation-rank=2.67/24
  - mean permanent RMS=0.026347
  - mean elastic RMS=0.007136
  - top residual-energy heads: h7=21.9%, h1=20.7%, h2=13.4%, h13=12.2%, h4=7.3%
  - mean |functional cosine|=0.172, frac |cos|>.8=0.0%, mean |parameter cosine|=0.002
- L05:
  - all heads entropy-rank=12.04/32, participation-rank=7.88/32
  - permanent heads entropy-rank=5.16/8, participation-rank=4.12/8
  - elastic heads entropy-rank=10.72/24, participation-rank=8.37/24
  - mean permanent RMS=0.004880
  - mean elastic RMS=0.001633
  - top residual-energy heads: h0=22.4%, h1=21.4%, h5=10.4%, h28=6.8%, h8=4.7%
  - mean |functional cosine|=0.011, frac |cos|>.8=0.0%, mean |parameter cosine|=0.005
- L11:
  - all heads entropy-rank=13.27/32, participation-rank=7.31/32
  - permanent heads entropy-rank=3.58/8, participation-rank=2.20/8
  - elastic heads entropy-rank=11.77/24, participation-rank=8.54/24
  - mean permanent RMS=0.002226
  - mean elastic RMS=0.001359
  - top residual-energy heads: h6=30.7%, h18=11.0%, h31=8.3%, h19=7.9%, h14=5.4%
  - mean |functional cosine|=0.013, frac |cos|>.8=0.0%, mean |parameter cosine|=0.004

### How to use this for the proposed nonlinear 1024→2048 refinement
- If functional effective rank is low / output similarities are high even though parameter similarities are modest, the expanded attention head bank is producing redundant residual features. That is evidence worth testing a nonlinear head-refinement/expansion ablation.
- If head outputs are diverse but router-logit/utility alignment is poor and random-same-count is competitive, the attention expansion is probably not the first bottleneck; the selector is.
- If head outputs are diverse and router selection is good, but dense still beats routed, the 0/1 mixture may be too coarse; that is the strongest case for testing weighted active-head contributions next.

## 5. Exact dense single-head ablations
Mean ΔCE: +0.009089; max ΔCE: +0.336573; min ΔCE: -0.001160
