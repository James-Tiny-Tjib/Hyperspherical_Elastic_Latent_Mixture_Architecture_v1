#!/usr/bin/env python3
"""
HELM_7c checkpoint head-dynamics / redundancy diagnostic.

Default checkpoint:
  repo: JamesResearch1216/HELM_7c
  file: checkpoint-006500.pt

What this script tests
----------------------
1) Router/cardinality behavior
   - actual head counts vs easiness-derived targets
   - easiness/count Spearman correlation
   - per-head activation frequency and mask diversity
   - sigmoid saturation and STE derivative health
   - router logit variance across inputs vs across heads

2) Quality of routing decisions
   - routed CE
   - forced-dense CE (all 32 heads)
   - permanent-only CE (8 permanent heads)
   - random-same-count CE (same compute as HELM, random elastic identities)
   - first-order same-count "oracle" CE on a small subset

3) Router/utility alignment
   - freeze all model parameters
   - temporarily replace each layer's router mask by differentiable per-example gates
   - force all heads on and compute |d CE / d gate_h|
   - compare this CE importance to HELM's elastic router logits
   - measure active-vs-inactive importance and top-k overlap

4) Functional head redundancy
   - capture the hidden state entering layers 0, 5, and 11 (configurable)
   - recompute ALL 32 heads' attention context BEFORE router masking
   - project every head separately through its own slice of W_O
   - compare residual-stream contributions Y_h = C_h W_O^(h)
   - report pairwise cosine similarity and effective rank

5) Parameter redundancy (secondary diagnostic)
   - pairwise cosine similarity of concatenated Q/K/V/O head parameter blocks

The script intentionally uses a deterministic diagnostic MLM mask. Its CE values are
for RELATIVE comparisons inside this script, not for reproducing the trainer's exact
validation loss.

Outputs
-------
<output_dir>/
  summary.md
  summary.json
  count_calibration.csv
  layer_XX_head_stats.csv
  layer_XX_functional_similarity.csv
  layer_XX_parameter_similarity.csv
  layer_XX_*.png
  utility_alignment.csv
  HELM_7c_head_analysis_results.zip

Run examples
------------
GPU:
  python analyze_helm7c_heads.py --device cuda

Single TPU/XLA device (after your normal Kaggle TPU repair/restart cell):
  python analyze_helm7c_heads.py --device xla --batch-size 2

CPU (slow):
  python analyze_helm7c_heads.py --device cpu --num-examples 8 --seq-len 256

For a heavier exact single-head ablation diagnostic:
  python analyze_helm7c_heads.py --device cuda --exact-ablation
"""

from __future__ import annotations

import argparse
import contextlib
import csv
import glob
import json
import math
import os
import random
import shutil
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn.functional as F

# Matplotlib only; no seaborn dependency.
import matplotlib.pyplot as plt

try:
    from huggingface_hub import hf_hub_download
except Exception as exc:
    raise RuntimeError(
        "huggingface_hub is required. Install it with: pip install huggingface_hub"
    ) from exc

try:
    import pyarrow.parquet as pq
except Exception as exc:
    raise RuntimeError("pyarrow is required. Install it with: pip install pyarrow") from exc

# model.py must be next to this script (included in the bundle I provided).
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

try:
    from model import HELMConfig, HELMForMaskedLM, justnorm, cast_linear
except Exception as exc:
    raise RuntimeError(
        "Could not import HELM_7c model.py. Put the HELM_7c model.py in the same directory "
        "as analyze_helm7c_heads.py."
    ) from exc


# -----------------------------------------------------------------------------
# Constants / defaults
# -----------------------------------------------------------------------------
MODEL_REPO = "JamesResearch1216/HELM_7c"
CHECKPOINT_FILE = "checkpoint-006500.pt"
TRAINING_STATE_FILE = "training_state.json"
DATA_REPO = "JamesResearch1216/HELM-Easiness-Data-10B-Labeled-v6"
VALIDATION_FILE = "data/seq_1024/validation-00000.parquet"


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def get_hf_token() -> Optional[str]:
    """Resolve HF token without requiring one for public repositories."""
    token = os.getenv("HF_TOKEN") or os.getenv("HUGGING_FACE_HUB_TOKEN")
    if token:
        return token
    try:
        from kaggle_secrets import UserSecretsClient
        return UserSecretsClient().get_secret("HF_TOKEN")
    except Exception:
        return None


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def strip_state_prefixes(state: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    """Handle DDP / torch.compile prefixes defensively."""
    out = {}
    for key, value in state.items():
        k = key
        changed = True
        while changed:
            changed = False
            for prefix in ("module.", "_orig_mod."):
                if k.startswith(prefix):
                    k = k[len(prefix):]
                    changed = True
        out[k] = value
    return out


def double_argsort_rank(x: torch.Tensor, descending: bool = True) -> torch.Tensor:
    """Return integer rank per row, rank 0 = largest when descending=True."""
    order = torch.argsort(x, dim=-1, descending=descending)
    return torch.argsort(order, dim=-1)


def rankdata_np(x: np.ndarray) -> np.ndarray:
    """Simple average-tie rank data, sufficient for diagnostics."""
    x = np.asarray(x)
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty(len(x), dtype=np.float64)
    sorted_x = x[order]
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and sorted_x[j] == sorted_x[i]:
            j += 1
        avg_rank = 0.5 * (i + j - 1)
        ranks[order[i:j]] = avg_rank
        i = j
    return ranks


def spearman_np(x: Sequence[float], y: Sequence[float]) -> float:
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    y = np.asarray(y, dtype=np.float64).reshape(-1)
    good = np.isfinite(x) & np.isfinite(y)
    x = x[good]
    y = y[good]
    if len(x) < 3 or np.std(x) == 0 or np.std(y) == 0:
        return float("nan")
    rx = rankdata_np(x)
    ry = rankdata_np(y)
    return float(np.corrcoef(rx, ry)[0, 1])


def effective_rank_from_gram(gram: np.ndarray) -> Tuple[float, float, np.ndarray]:
    """Return entropy effective rank, participation rank, eigenvalues."""
    g = 0.5 * (gram + gram.T)
    vals = np.linalg.eigvalsh(g)
    vals = np.clip(vals, 0.0, None)
    total = vals.sum()
    if total <= 1e-12:
        return 0.0, 0.0, vals
    p = vals / total
    p_pos = p[p > 1e-12]
    entropy_rank = float(np.exp(-(p_pos * np.log(p_pos)).sum()))
    participation = float((total * total) / (np.square(vals).sum() + 1e-12))
    return entropy_rank, participation, vals


def cosine_from_gram(gram: np.ndarray) -> np.ndarray:
    diag = np.clip(np.diag(gram), 1e-12, None)
    denom = np.sqrt(np.outer(diag, diag))
    cos = gram / denom
    return np.clip(cos, -1.0, 1.0)


def offdiag_stats(matrix: np.ndarray, threshold: float = 0.80) -> Dict[str, float]:
    n = matrix.shape[0]
    mask = ~np.eye(n, dtype=bool)
    vals = np.abs(matrix[mask])
    if vals.size == 0:
        return {"mean_abs": 0.0, "median_abs": 0.0, "frac_abs_gt_0.8": 0.0, "max_abs": 0.0}
    return {
        "mean_abs": float(vals.mean()),
        "median_abs": float(np.median(vals)),
        "frac_abs_gt_0.8": float((vals > threshold).mean()),
        "max_abs": float(vals.max()),
    }


def top_pairs(matrix: np.ndarray, k: int = 8) -> List[Tuple[int, int, float]]:
    pairs = []
    for i in range(matrix.shape[0]):
        for j in range(i + 1, matrix.shape[1]):
            pairs.append((i, j, float(matrix[i, j])))
    pairs.sort(key=lambda t: abs(t[2]), reverse=True)
    return pairs[:k]


def save_matrix_csv(path: Path, matrix: np.ndarray, prefix: str = "head") -> None:
    with path.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([""] + [f"{prefix}_{i}" for i in range(matrix.shape[1])])
        for i, row in enumerate(matrix):
            writer.writerow([f"{prefix}_{i}"] + [float(v) for v in row])


def save_heatmap(path: Path, matrix: np.ndarray, title: str, xlabel: str, ylabel: str,
                 vmin: Optional[float] = None, vmax: Optional[float] = None) -> None:
    fig, ax = plt.subplots(figsize=(10, 7))
    im = ax.imshow(matrix, aspect="auto", interpolation="nearest", vmin=vmin, vmax=vmax)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def save_bar(path: Path, values: np.ndarray, title: str, ylabel: str) -> None:
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.bar(np.arange(len(values)), values)
    ax.set_title(title)
    ax.set_xlabel("Head")
    ax.set_ylabel(ylabel)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


# -----------------------------------------------------------------------------
# Device abstraction
# -----------------------------------------------------------------------------
@dataclass
class DeviceContext:
    device: torch.device
    kind: str
    xm: object = None
    autocast_dtype: Optional[torch.dtype] = None

    def autocast(self):
        if self.kind == "cuda":
            return torch.autocast(device_type="cuda", dtype=self.autocast_dtype)
        if self.kind == "xla":
            try:
                return torch.autocast(device_type="xla", dtype=torch.bfloat16)
            except Exception:
                return contextlib.nullcontext()
        return contextlib.nullcontext()

    def mark_step(self):
        if self.kind == "xla" and self.xm is not None:
            self.xm.mark_step()


def resolve_device(requested: str) -> DeviceContext:
    requested = requested.lower()
    if requested == "auto":
        if torch.cuda.is_available():
            requested = "cuda"
        elif glob.glob("/dev/accel*"):
            requested = "xla"
        else:
            requested = "cpu"

    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("--device cuda requested but CUDA is not available")
        if torch.cuda.is_bf16_supported():
            dtype = torch.bfloat16
        else:
            dtype = torch.float16
        return DeviceContext(torch.device("cuda"), "cuda", autocast_dtype=dtype)

    if requested == "xla":
        # Assumes the user already ran/restarted with the same TPU environment setup used
        # by HELM training.
        try:
            import torch_xla.core.xla_model as xm
        except Exception as exc:
            raise RuntimeError(
                "--device xla requested but torch_xla could not be imported. Run your normal "
                "TPU repair/restart cell first."
            ) from exc
        return DeviceContext(xm.xla_device(), "xla", xm=xm, autocast_dtype=torch.bfloat16)

    if requested == "cpu":
        return DeviceContext(torch.device("cpu"), "cpu", autocast_dtype=None)

    raise ValueError(f"Unknown device: {requested}")


# -----------------------------------------------------------------------------
# Checkpoint / data loading
# -----------------------------------------------------------------------------
def download_assets(cache_dir: Path, token: Optional[str], model_repo: str,
                    checkpoint_file: str, data_repo: str, validation_file: str):
    cache_dir.mkdir(parents=True, exist_ok=True)
    print(f"Downloading checkpoint: {model_repo}/{checkpoint_file}")
    ckpt_path = hf_hub_download(
        repo_id=model_repo,
        filename=checkpoint_file,
        repo_type="model",
        token=token,
        local_dir=str(cache_dir / "model_repo"),
    )

    training_state_path = None
    try:
        training_state_path = hf_hub_download(
            repo_id=model_repo,
            filename=TRAINING_STATE_FILE,
            repo_type="model",
            token=token,
            local_dir=str(cache_dir / "model_repo"),
        )
    except Exception as exc:
        print(f"WARNING: could not download training_state.json: {exc}")

    print(f"Downloading validation shard: {data_repo}/{validation_file}")
    validation_path = hf_hub_download(
        repo_id=data_repo,
        filename=validation_file,
        repo_type="dataset",
        token=token,
        local_dir=str(cache_dir / "dataset"),
    )
    return Path(ckpt_path), (Path(training_state_path) if training_state_path else None), Path(validation_path)


def load_breakpoints(training_state_path: Optional[Path]) -> Optional[List[float]]:
    if training_state_path is None or not training_state_path.exists():
        return None
    try:
        with training_state_path.open("r") as f:
            state = json.load(f)
        easiness_dict = state.get("easiness_dict")
        if isinstance(easiness_dict, dict):
            bp = easiness_dict.get("breakpoints")
            if bp:
                print(f"Loaded {len(bp)} easiness CDF breakpoints from training_state.json")
                return bp
    except Exception as exc:
        print(f"WARNING: failed to parse easiness breakpoints: {exc}")
    return None


def load_model(ckpt_path: Path, breakpoints: Optional[List[float]], dev: DeviceContext):
    config = HELMConfig(easiness_cdf_breakpoints=breakpoints)
    model = HELMForMaskedLM(config)
    print(f"Loading checkpoint from {ckpt_path}")
    payload = torch.load(str(ckpt_path), map_location="cpu")
    if not isinstance(payload, dict):
        raise RuntimeError("Checkpoint is not a dict")
    state = payload.get("model_state", payload)
    state = strip_state_prefixes(state)
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        print(f"State load: {len(missing)} missing keys, {len(unexpected)} unexpected keys")
        if missing:
            print("  Missing (first 10):", missing[:10])
        if unexpected:
            print("  Unexpected (first 10):", unexpected[:10])
        # The analysis should not silently continue through a large mismatch.
        if len(missing) > 5 or len(unexpected) > 5:
            raise RuntimeError("Large state-dict mismatch; make sure this is HELM_7c model.py")
    del payload
    model.to(dev.device)
    model.eval()
    # Force the same fixed-shape dense attention backend used during training, then mask.
    model.enable_efficient_inference("dense", compile=False)
    return model, config


def deterministic_span_mask(ids: torch.Tensor, config: HELMConfig, seed: int,
                            probability: float = 0.30, span_length: int = 3) -> Tuple[torch.Tensor, torch.Tensor]:
    """Create one deterministic MLM example. Relative CE comparisons are the goal."""
    ids = ids.clone().long()
    labels = torch.full_like(ids, -100)
    g = torch.Generator(device="cpu")
    g.manual_seed(int(seed))

    special = {
        int(config.bos_token_id), int(config.eos_token_id), int(config.pad_token_id),
        int(config.mask_token_id), int(config.unk_token_id),
    }
    candidate = [i for i, tok in enumerate(ids.tolist()) if int(tok) not in special]
    if not candidate:
        return ids, labels

    target = max(1, int(round(probability * len(candidate))))
    candidate_set = set(candidate)
    perm = torch.randperm(len(candidate), generator=g).tolist()
    chosen = set()
    for pi in perm:
        if len(chosen) >= target:
            break
        start = candidate[pi]
        for pos in range(start, min(start + span_length, ids.numel())):
            if pos in candidate_set:
                chosen.add(pos)
                if len(chosen) >= target:
                    break

    chosen = sorted(chosen)
    if not chosen:
        chosen = [candidate[0]]
    pos = torch.tensor(chosen, dtype=torch.long)
    original = ids[pos].clone()
    labels[pos] = original

    r = torch.rand(len(pos), generator=g)
    mask_sel = r < 0.80
    random_sel = (r >= 0.80) & (r < 0.90)
    ids[pos[mask_sel]] = int(config.mask_token_id)
    if random_sel.any():
        random_tokens = torch.randint(
            low=0, high=int(config.vocab_size), size=(int(random_sel.sum()),), generator=g
        )
        ids[pos[random_sel]] = random_tokens
    # remaining 10% unchanged
    return ids, labels


def prepare_batches(validation_path: Path, config: HELMConfig, num_examples: int,
                    batch_size: int, seq_len: int, seed: int) -> List[Dict[str, torch.Tensor]]:
    table = pq.read_table(str(validation_path), columns=["input_ids", "easiness_score"])
    if "input_ids" not in table.column_names or "easiness_score" not in table.column_names:
        raise RuntimeError(f"Validation parquet columns are {table.column_names}; expected input_ids and easiness_score")

    total_rows = table.num_rows
    n = min(num_examples, total_rows)
    rng = np.random.default_rng(seed)
    indices = rng.permutation(total_rows)[:n]
    input_col = table.column("input_ids")
    easy_col = table.column("easiness_score")

    examples = []
    for i, row_idx in enumerate(indices.tolist()):
        ids_list = input_col[row_idx].as_py()
        easy_val = easy_col[row_idx].as_py()
        ids = torch.tensor(ids_list, dtype=torch.long)[:seq_len]
        if ids.numel() < seq_len:
            pad = torch.full((seq_len - ids.numel(),), int(config.pad_token_id), dtype=torch.long)
            ids = torch.cat([ids, pad], dim=0)
        masked, labels = deterministic_span_mask(ids, config, seed=seed + 100003 * i)
        examples.append({
            "input_ids": masked,
            "labels": labels,
            "attention_mask": (masked != int(config.pad_token_id)).long(),
            "easiness_score": torch.tensor(float(easy_val), dtype=torch.float32),
            "example_id": torch.tensor(i, dtype=torch.long),
        })

    # Drop an incomplete final batch to keep XLA/static shapes stable.
    usable = (len(examples) // batch_size) * batch_size
    examples = examples[:usable]
    if not examples:
        raise RuntimeError("Not enough examples for one complete batch")

    batches = []
    for start in range(0, len(examples), batch_size):
        chunk = examples[start:start + batch_size]
        batches.append({k: torch.stack([x[k] for x in chunk], dim=0) for k in chunk[0]})
    print(f"Prepared {len(examples)} examples -> {len(batches)} batches of {batch_size}, seq_len={seq_len}")
    return batches


def move_batch(batch: Dict[str, torch.Tensor], dev: DeviceContext) -> Dict[str, torch.Tensor]:
    return {k: v.to(dev.device) for k, v in batch.items()}


# -----------------------------------------------------------------------------
# CE helpers
# -----------------------------------------------------------------------------
def ce_sum_and_count(logits: torch.Tensor, labels: torch.Tensor, chunk_tokens: int = 128):
    """Fixed-shape chunked CE. Returns differentiable sum and integer-ish tensor count."""
    total = logits.new_zeros((), dtype=torch.float32)
    count = labels.new_zeros((), dtype=torch.long)
    seq_len = logits.size(1)
    vocab = logits.size(-1)
    for start in range(0, seq_len, chunk_tokens):
        end = min(start + chunk_tokens, seq_len)
        lgt = logits[:, start:end, :].float().reshape(-1, vocab)
        lab = labels[:, start:end].reshape(-1)
        total = total + F.cross_entropy(lgt, lab, ignore_index=-100, reduction="sum")
        count = count + (lab != -100).sum()
    return total, count


def forward_ce(model, batch: Dict[str, torch.Tensor], dev: DeviceContext,
               pass_easiness: bool = True, backward: bool = False):
    kwargs = {
        "input_ids": batch["input_ids"],
        "attention_mask": batch["attention_mask"],
        "current_step": 6500,
        "easiness_score": batch["easiness_score"] if pass_easiness else None,
    }
    with dev.autocast():
        logits, count_loss = model(**kwargs)
        ce_sum, ce_count = ce_sum_and_count(logits, batch["labels"])
        ce = ce_sum / ce_count.clamp_min(1).to(ce_sum.dtype)
    if backward:
        ce.backward()
        dev.mark_step()
    return ce, ce_sum, ce_count, count_loss


# -----------------------------------------------------------------------------
# Router mask override hooks
# -----------------------------------------------------------------------------
class RouterOverride:
    """Temporarily replace every router's [B,H,1,1] output without changing shapes."""
    def __init__(self, model, mode: str, permanent_heads: int, forced_masks: Optional[Dict[int, torch.Tensor]] = None):
        self.model = model
        self.mode = mode
        self.permanent_heads = permanent_heads
        self.forced_masks = forced_masks or {}
        self.handles = []
        self.gates: Dict[int, torch.Tensor] = {}

    def _hook(self, layer_idx: int):
        def hook(module, inputs, output):
            b, h, _, _ = output.shape
            p = self.permanent_heads
            if self.mode == "dense":
                return torch.ones_like(output)
            if self.mode == "permanent_only":
                result = torch.zeros_like(output)
                result[:, :p] = 1.0
                return result
            if self.mode == "random_same_count":
                elastic = output[:, p:, 0, 0]
                k = (elastic > 0.5).sum(dim=-1, keepdim=True)
                noise = torch.rand_like(elastic.float())
                ranks = double_argsort_rank(noise, descending=True)
                rand_elastic = (ranks < k).to(output.dtype)
                permanent = torch.ones((b, p), device=output.device, dtype=output.dtype)
                return torch.cat([permanent, rand_elastic], dim=-1).view(b, h, 1, 1)
            if self.mode == "forced":
                if layer_idx not in self.forced_masks:
                    return output
                mask = self.forced_masks[layer_idx].to(device=output.device, dtype=output.dtype)
                return mask.view(b, h, 1, 1)
            if self.mode == "gate_dense":
                gate = torch.ones_like(output, requires_grad=True)
                self.gates[layer_idx] = gate
                return gate
            if self.mode == "gate_routed":
                gate = torch.ones_like(output, requires_grad=True)
                self.gates[layer_idx] = gate
                return output * gate
            raise ValueError(f"Unknown override mode {self.mode}")
        return hook

    def __enter__(self):
        for i, block in enumerate(self.model.model.blocks):
            self.handles.append(block.mlt_vw_rtr.register_forward_hook(self._hook(i)))
        return self

    def __exit__(self, exc_type, exc, tb):
        for h in self.handles:
            h.remove()
        self.handles.clear()


# -----------------------------------------------------------------------------
# Router statistics
# -----------------------------------------------------------------------------
def collect_router_statistics(model, batches, dev: DeviceContext, output_dir: Path, selected_layers: Sequence[int]):
    n_layers = len(model.model.blocks)
    logits_by_layer = [[] for _ in range(n_layers)]
    sig_by_layer = [[] for _ in range(n_layers)]
    mask_by_layer = [[] for _ in range(n_layers)]
    actual_by_layer = [[] for _ in range(n_layers)]
    target_by_layer = [[] for _ in range(n_layers)]
    easiness_all = []
    ce_total = 0.0
    ce_tokens = 0

    with torch.no_grad():
        for bi, cpu_batch in enumerate(batches):
            batch = move_batch(cpu_batch, dev)
            ce, ce_sum, ce_count, _ = forward_ce(model, batch, dev, pass_easiness=True)
            dev.mark_step()
            ce_total += float(ce_sum.detach().cpu())
            ce_tokens += int(ce_count.detach().cpu())
            easiness_all.append(cpu_batch["easiness_score"].numpy())

            for li, block in enumerate(model.model.blocks):
                r = block.mlt_vw_rtr
                logits_by_layer[li].append(r.save_router_logits.detach().float().cpu().numpy())
                sig_by_layer[li].append(r.save_sigmoid_scores.detach().float().cpu().numpy())
                mask_by_layer[li].append(r.save_hard_mask.detach().float().cpu().numpy())
                actual_by_layer[li].append(r.save_total_head_count.detach().float().cpu().numpy())
                target_by_layer[li].append(r.save_target_total_head_count.detach().float().cpu().numpy())

    easiness = np.concatenate(easiness_all, axis=0)
    per_layer = {}
    calibration_rows = []

    for li in range(n_layers):
        logits = np.concatenate(logits_by_layer[li], axis=0)
        sig = np.concatenate(sig_by_layer[li], axis=0)
        mask = np.concatenate(mask_by_layer[li], axis=0)
        actual = np.concatenate(actual_by_layer[li], axis=0)
        target = np.concatenate(target_by_layer[li], axis=0)
        freq = mask.mean(axis=0)
        weight_norms = (
            model.model.blocks[li].mlt_vw_rtr.q_up_proj.weight.detach().float().norm(dim=1).cpu().numpy()
        )

        stats = {
            "actual_mean": float(actual.mean()),
            "target_mean": float(target.mean()),
            "count_mae": float(np.abs(actual - target).mean()),
            "count_error_mean": float((actual - target).mean()),
            "easiness_actual_spearman": spearman_np(easiness, actual),
            "target_actual_spearman": spearman_np(target, actual),
            "dynamic_head_fraction_05_95": float(((freq > 0.05) & (freq < 0.95)).mean()),
            "always_off_fraction_lt_01": float((freq < 0.01).mean()),
            "always_on_fraction_gt_99": float((freq > 0.99).mean()),
            "expected_pairwise_mask_hamming": float(np.mean(2.0 * freq * (1.0 - freq))),
            "logit_input_variance_mean": float(logits.var(axis=0).mean()),
            "logit_across_head_variance_mean": float(logits.var(axis=1).mean()),
            "sigmoid_mean": float(sig.mean()),
            "sigmoid_saturation_lt05_gt95": float(((sig < 0.05) | (sig > 0.95)).mean()),
            "sigmoid_near_half_45_55": float(((sig > 0.45) & (sig < 0.55)).mean()),
            "ste_derivative_mean": float((sig * (1.0 - sig)).mean()),
            "router_weight_norm_mean": float(weight_norms.mean()),
            "router_weight_norm_std": float(weight_norms.std()),
            "min_total_head_fraction": float((actual == model.config.head_target_min).mean()),
            "max_total_head_fraction": float((actual == model.config.head_target_max).mean()),
        }
        per_layer[li] = stats

        rows = []
        for h in range(mask.shape[1]):
            rows.append({
                "layer": li,
                "elastic_head": h,
                "absolute_head": h + model.config.num_permanent_heads,
                "activation_frequency": float(freq[h]),
                "mean_logit": float(logits[:, h].mean()),
                "std_logit_across_examples": float(logits[:, h].std()),
                "mean_sigmoid": float(sig[:, h].mean()),
                "router_weight_norm": float(weight_norms[h]),
            })
        with (output_dir / f"layer_{li:02d}_head_stats.csv").open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader(); writer.writerows(rows)

        # Count calibration by integer target.
        for t in range(int(model.config.head_target_min), int(model.config.head_target_max) + 1):
            idx = target == t
            if idx.any():
                calibration_rows.append({
                    "layer": li,
                    "target_heads": t,
                    "n": int(idx.sum()),
                    "actual_mean": float(actual[idx].mean()),
                    "actual_std": float(actual[idx].std()),
                    "mae": float(np.abs(actual[idx] - target[idx]).mean()),
                    "fraction_exact": float((actual[idx] == target[idx]).mean()),
                })

        if li in selected_layers:
            save_heatmap(
                output_dir / f"layer_{li:02d}_activation_heatmap.png",
                mask, f"Layer {li}: elastic hard activations", "Elastic head", "Example", 0.0, 1.0,
            )
            save_heatmap(
                output_dir / f"layer_{li:02d}_sigmoid_heatmap.png",
                sig, f"Layer {li}: sigmoid scores", "Elastic head", "Example", 0.0, 1.0,
            )
            save_bar(
                output_dir / f"layer_{li:02d}_activation_frequency.png",
                freq, f"Layer {li}: elastic activation frequency", "Activation frequency",
            )
            save_bar(
                output_dir / f"layer_{li:02d}_router_weight_norms.png",
                weight_norms, f"Layer {li}: router row norms", "L2 norm",
            )

    if calibration_rows:
        with (output_dir / "count_calibration.csv").open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=calibration_rows[0].keys())
            writer.writeheader(); writer.writerows(calibration_rows)

    return {
        "routed_ce": ce_total / max(1, ce_tokens),
        "easiness": easiness,
        "per_layer": per_layer,
        "logits": [np.concatenate(x, axis=0) for x in logits_by_layer],
        "sigmoid": [np.concatenate(x, axis=0) for x in sig_by_layer],
        "masks": [np.concatenate(x, axis=0) for x in mask_by_layer],
        "actual": [np.concatenate(x, axis=0) for x in actual_by_layer],
        "target": [np.concatenate(x, axis=0) for x in target_by_layer],
    }


# -----------------------------------------------------------------------------
# CE mode comparisons
# -----------------------------------------------------------------------------
def evaluate_override_mode(model, batches, dev: DeviceContext, mode: str, random_seed: int = 0) -> float:
    total_sum = 0.0
    total_count = 0
    seed_everything(random_seed)
    manager = contextlib.nullcontext() if mode == "routed" else RouterOverride(
        model, mode, model.config.num_permanent_heads
    )
    with manager:
        with torch.no_grad():
            for cpu_batch in batches:
                batch = move_batch(cpu_batch, dev)
                _, ce_sum, ce_count, _ = forward_ce(model, batch, dev, pass_easiness=False)
                dev.mark_step()
                total_sum += float(ce_sum.detach().cpu())
                total_count += int(ce_count.detach().cpu())
    return total_sum / max(1, total_count)


# -----------------------------------------------------------------------------
# Utility / alignment analysis
# -----------------------------------------------------------------------------
def build_topk_mask_from_importance(importance: torch.Tensor, baseline_full_mask: torch.Tensor,
                                    permanent_heads: int) -> torch.Tensor:
    """Keep permanent heads + same elastic count as HELM, but choose highest-importance elastic heads."""
    p = permanent_heads
    imp_e = importance[:, p:]
    base_e = baseline_full_mask[:, p:]
    k = (base_e > 0.5).sum(dim=-1, keepdim=True)
    ranks = double_argsort_rank(imp_e, descending=True)
    chosen = (ranks < k).to(importance.dtype)
    permanent = torch.ones((importance.size(0), p), device=importance.device, dtype=importance.dtype)
    return torch.cat([permanent, chosen], dim=-1)


def utility_alignment_analysis(model, batches, dev: DeviceContext, max_batches: int, output_dir: Path):
    # Model params are frozen: backward is ONLY to the temporary gate tensors.
    original_requires_grad = {id(p): p.requires_grad for p in model.parameters()}
    for p in model.parameters():
        p.requires_grad_(False)

    n_layers = len(model.model.blocks)
    rows = []
    oracle_ce_sum = 0.0
    oracle_tokens = 0
    subset_routed_sum = 0.0
    subset_routed_tokens = 0
    dense_gate_sum = 0.0
    dense_gate_tokens = 0

    for bi, cpu_batch in enumerate(batches[:max_batches]):
        batch = move_batch(cpu_batch, dev)

        # Baseline routed pass: store masks/logits for THIS exact batch.
        with torch.no_grad():
            _, rsum, rcount, _ = forward_ce(model, batch, dev, pass_easiness=True)
            dev.mark_step()
            subset_routed_sum += float(rsum.detach().cpu())
            subset_routed_tokens += int(rcount.detach().cpu())
            baseline_logits = [
                block.mlt_vw_rtr.save_router_logits.detach().float().cpu().numpy()
                for block in model.model.blocks
            ]
            baseline_elastic = [
                block.mlt_vw_rtr.save_hard_mask.detach().float().cpu().numpy()
                for block in model.model.blocks
            ]

        # Dense differentiable gates. One backward pass gives per-example importance for all 32 heads/layers.
        model.zero_grad(set_to_none=True)
        with RouterOverride(model, "gate_dense", model.config.num_permanent_heads) as gate_override:
            ce, dsum, dcount, _ = forward_ce(model, batch, dev, pass_easiness=False, backward=True)
            dense_gate_sum += float(dsum.detach().cpu())
            dense_gate_tokens += int(dcount.detach().cpu())

            importance_by_layer: Dict[int, torch.Tensor] = {}
            for li in range(n_layers):
                gate = gate_override.gates[li]
                if gate.grad is None:
                    raise RuntimeError(f"No gradient for temporary gate at layer {li}")
                importance_by_layer[li] = gate.grad.detach().abs()[:, :, 0, 0].float()

        # Build same-count first-order oracle masks for all layers simultaneously.
        forced_masks = {}
        for li in range(n_layers):
            p = model.config.num_permanent_heads
            elastic_np = baseline_elastic[li]
            full_base = torch.cat([
                torch.ones((elastic_np.shape[0], p), dtype=torch.float32),
                torch.tensor(elastic_np, dtype=torch.float32),
            ], dim=-1).to(dev.device)
            forced_masks[li] = build_topk_mask_from_importance(
                importance_by_layer[li], full_base, p
            ).detach()

            logits_np = baseline_logits[li]
            imp_np = importance_by_layer[li][:, p:].detach().cpu().numpy()
            base_np = elastic_np
            for ex in range(logits_np.shape[0]):
                k = int(base_np[ex].sum())
                corr = spearman_np(logits_np[ex], imp_np[ex])
                if k > 0:
                    top_idx = np.argsort(-imp_np[ex])[:k]
                    selected = np.flatnonzero(base_np[ex] > 0.5)
                    overlap = len(set(top_idx.tolist()) & set(selected.tolist())) / float(k)
                    selected_imp = float(imp_np[ex][selected].mean()) if len(selected) else float("nan")
                else:
                    overlap = 1.0
                    selected_imp = float("nan")
                inactive = np.flatnonzero(base_np[ex] <= 0.5)
                inactive_imp = float(imp_np[ex][inactive].mean()) if len(inactive) else float("nan")
                ratio = (
                    selected_imp / (inactive_imp + 1e-12)
                    if np.isfinite(selected_imp) and np.isfinite(inactive_imp) else float("nan")
                )
                rows.append({
                    "batch": bi,
                    "example_in_batch": ex,
                    "layer": li,
                    "elastic_k": k,
                    "logit_importance_spearman": corr,
                    "router_topk_overlap_with_utility": overlap,
                    "selected_importance_mean": selected_imp,
                    "inactive_importance_mean": inactive_imp,
                    "selected_to_inactive_importance_ratio": ratio,
                })

        with RouterOverride(model, "forced", model.config.num_permanent_heads, forced_masks=forced_masks):
            with torch.no_grad():
                _, osum, ocount, _ = forward_ce(model, batch, dev, pass_easiness=False)
                dev.mark_step()
                oracle_ce_sum += float(osum.detach().cpu())
                oracle_tokens += int(ocount.detach().cpu())

    # Restore flags for completeness.
    for p in model.parameters():
        p.requires_grad_(original_requires_grad[id(p)])

    if rows:
        with (output_dir / "utility_alignment.csv").open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader(); writer.writerows(rows)

    # Aggregate per layer.
    per_layer = {}
    for li in range(n_layers):
        rr = [r for r in rows if r["layer"] == li]
        def finite_mean(key):
            vals = np.array([r[key] for r in rr], dtype=np.float64)
            vals = vals[np.isfinite(vals)]
            return float(vals.mean()) if vals.size else float("nan")
        per_layer[li] = {
            "logit_importance_spearman_mean": finite_mean("logit_importance_spearman"),
            "router_topk_overlap_with_utility_mean": finite_mean("router_topk_overlap_with_utility"),
            "selected_to_inactive_importance_ratio_mean": finite_mean("selected_to_inactive_importance_ratio"),
        }

    return {
        "subset_routed_ce": subset_routed_sum / max(1, subset_routed_tokens),
        "dense_gate_ce": dense_gate_sum / max(1, dense_gate_tokens),
        "first_order_oracle_same_count_ce": oracle_ce_sum / max(1, oracle_tokens),
        "per_layer": per_layer,
    }


# -----------------------------------------------------------------------------
# Functional redundancy analysis
# -----------------------------------------------------------------------------
class AttentionInputCapture:
    def __init__(self, model, layers: Sequence[int]):
        self.model = model
        self.layers = set(layers)
        self.handles = []
        self.data: Dict[int, Tuple[torch.Tensor, torch.Tensor]] = {}

    def _hook(self, li: int):
        def hook(module, inputs):
            hidden_states, attention_mask, router_mask = inputs
            self.data[li] = (hidden_states.detach(), attention_mask.detach())
        return hook

    def __enter__(self):
        for li in self.layers:
            self.handles.append(
                self.model.model.blocks[li].attn.register_forward_pre_hook(self._hook(li))
            )
        return self

    def __exit__(self, exc_type, exc, tb):
        for h in self.handles:
            h.remove()
        self.handles.clear()


def unmasked_attention_context(attn, hidden_states: torch.Tensor, attention_mask: torch.Tensor):
    """Reproduce HELM_7c dense attention up through pre-router head contexts."""
    qkv_proj = cast_linear(hidden_states, attn.qkv)
    b, s, _ = hidden_states.shape
    q, k, v = qkv_proj.split(attn.total_head_dim, dim=-1)
    q = q.view(b, s, attn.num_attention_heads, attn.d_head).permute(0, 2, 1, 3)
    k = k.view(b, s, attn.num_attention_heads, attn.d_head).permute(0, 2, 1, 3)
    v = v.view(b, s, attn.num_attention_heads, attn.d_head).permute(0, 2, 1, 3)
    q = justnorm(q)
    k = justnorm(k)
    q = attn.RoPE(q)
    k = attn.RoPE(k)
    sqk = attn.sqk * (attn.ngpt_sqk_init_value / attn.ngpt_sqk_init_scale)
    sqk = sqk.view(1, attn.num_attention_heads, 1, attn.d_head).to(q.dtype)
    q = sqk * q
    k = sqk * k
    context = F.scaled_dot_product_attention(
        q, k, v,
        attn_mask=attention_mask.to(q.dtype),
        scale=math.sqrt(attn.d_head),
    )
    if attn.config.use_exclusive_attention:
        vn = F.normalize(v, dim=-1)
        context = context - (context * vn).sum(dim=-1, keepdim=True) * vn
    return context


def parameter_head_cosine(attn) -> np.ndarray:
    h, d = attn.num_attention_heads, attn.d_head
    D = attn.hidden_size
    qkv = attn.qkv.weight.detach().float().cpu()
    q, k, v = qkv.split(attn.total_head_dim, dim=0)
    q = q.view(h, d, D).reshape(h, -1)
    k = k.view(h, d, D).reshape(h, -1)
    v = v.view(h, d, D).reshape(h, -1)
    # output.weight = [D, H*d]; each head owns one contiguous input-column block.
    o = attn.output.weight.detach().float().cpu().view(D, h, d).permute(1, 0, 2).reshape(h, -1)
    vec = torch.cat([q, k, v, o], dim=1)
    vec = F.normalize(vec, dim=1)
    return (vec @ vec.T).numpy()


def functional_redundancy_analysis(model, batches, dev: DeviceContext, layers: Sequence[int],
                                   max_batches: int, sample_tokens: int, output_dir: Path):
    grams = {li: np.zeros((model.config.num_attention_heads, model.config.num_attention_heads), dtype=np.float64)
             for li in layers}
    sample_count = {li: 0 for li in layers}

    with torch.no_grad():
        for bi, cpu_batch in enumerate(batches[:max_batches]):
            batch = move_batch(cpu_batch, dev)
            with AttentionInputCapture(model, layers) as cap:
                with dev.autocast():
                    _ = model(
                        input_ids=batch["input_ids"],
                        attention_mask=batch["attention_mask"],
                        current_step=6500,
                        easiness_score=batch["easiness_score"],
                    )
                dev.mark_step()

            for li in layers:
                hidden, attn_mask = cap.data[li]
                attn = model.model.blocks[li].attn
                with dev.autocast():
                    context = unmasked_attention_context(attn, hidden, attn_mask)  # [B,H,S,d]
                    s = context.size(2)
                    t = min(sample_tokens, s)
                    # Deterministic, spread-out positions to avoid only sampling one local region.
                    positions = torch.linspace(0, s - 1, steps=t, device=context.device).long()
                    c = context.index_select(2, positions)  # [B,H,T,d]
                    W = attn.output.weight.to(c.dtype).view(attn.hidden_size, attn.num_attention_heads, attn.d_head)
                    # Per-head residual contribution Y_h = C_h @ W_O^(h)^T.
                    y = torch.einsum("bhtd,ohd->bhto", c, W)  # [B,H,T,D]
                    flat = y.permute(1, 0, 2, 3).contiguous().view(attn.num_attention_heads, -1).float()
                    gram = flat @ flat.T
                dev.mark_step()
                grams[li] += gram.detach().cpu().numpy().astype(np.float64)
                sample_count[li] += int(flat.shape[1])
                del context, c, y, flat, gram

    results = {}
    for li in layers:
        gram = grams[li]
        functional_cos = cosine_from_gram(gram)
        erank, prank, eig = effective_rank_from_gram(gram)
        param_cos = parameter_head_cosine(model.model.blocks[li].attn)
        fstats = offdiag_stats(functional_cos)
        pstats = offdiag_stats(param_cos)

        results[li] = {
            "functional_entropy_effective_rank": erank,
            "functional_participation_rank": prank,
            "functional_similarity": fstats,
            "parameter_similarity": pstats,
            "top_functional_pairs": top_pairs(functional_cos, 8),
            "top_parameter_pairs": top_pairs(param_cos, 8),
        }

        save_matrix_csv(output_dir / f"layer_{li:02d}_functional_similarity.csv", functional_cos)
        save_matrix_csv(output_dir / f"layer_{li:02d}_parameter_similarity.csv", param_cos)
        save_heatmap(
            output_dir / f"layer_{li:02d}_functional_similarity.png",
            functional_cos,
            f"Layer {li}: cosine of unmasked residual head contributions",
            "Head", "Head", -1.0, 1.0,
        )
        save_heatmap(
            output_dir / f"layer_{li:02d}_parameter_similarity.png",
            param_cos,
            f"Layer {li}: cosine of concatenated Q/K/V/O head parameters",
            "Head", "Head", -1.0, 1.0,
        )

        # Eigen spectrum plot.
        vals = np.sort(np.clip(eig, 0, None))[::-1]
        frac = vals / (vals.sum() + 1e-12)
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(np.arange(1, len(frac) + 1), frac, marker="o")
        ax.set_title(f"Layer {li}: head-contribution Gram eigenvalue spectrum")
        ax.set_xlabel("Component")
        ax.set_ylabel("Fraction of head-space energy")
        fig.tight_layout()
        fig.savefig(output_dir / f"layer_{li:02d}_functional_eigenspectrum.png", dpi=160)
        plt.close(fig)

    return results


# -----------------------------------------------------------------------------
# Optional exact single-head ablation
# -----------------------------------------------------------------------------
def exact_ablation_analysis(model, batches, dev: DeviceContext, layers: Sequence[int], max_batches: int,
                            output_dir: Path):
    """Slow but interpretable: from forced-dense mode, remove one head in one selected layer."""
    subset = batches[:max_batches]
    dense_ce = evaluate_override_mode(model, subset, dev, "dense")
    rows = []
    H = model.config.num_attention_heads

    for li in layers:
        for head in range(H):
            total_sum = 0.0
            total_count = 0
            for cpu_batch in subset:
                batch = move_batch(cpu_batch, dev)
                b = batch["input_ids"].size(0)
                # All layers dense; one layer gets dense-minus-one-head.
                forced = {}
                for lj in range(len(model.model.blocks)):
                    m = torch.ones((b, H), dtype=torch.float32, device=dev.device)
                    if lj == li:
                        m[:, head] = 0.0
                    forced[lj] = m
                with RouterOverride(model, "forced", model.config.num_permanent_heads, forced_masks=forced):
                    with torch.no_grad():
                        _, s, c, _ = forward_ce(model, batch, dev, pass_easiness=False)
                        dev.mark_step()
                        total_sum += float(s.detach().cpu())
                        total_count += int(c.detach().cpu())
            ce = total_sum / max(1, total_count)
            rows.append({
                "layer": li,
                "head": head,
                "dense_ce": dense_ce,
                "ablated_ce": ce,
                "delta_ce": ce - dense_ce,
            })
            print(f"Exact ablation layer {li} head {head:02d}: ΔCE={ce-dense_ce:+.6f}")

    with (output_dir / "exact_single_head_ablation.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader(); writer.writerows(rows)
    return {"dense_ce_subset": dense_ce, "rows": rows}


# -----------------------------------------------------------------------------
# Reporting
# -----------------------------------------------------------------------------
def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, float) and not np.isfinite(obj):
        return None
    return obj


def write_summary(output_dir: Path, args, router_stats, ce_modes, utility, redundancy, exact):
    lines = []
    lines.append("# HELM_7c Head Dynamics Analysis\n")
    lines.append(f"Checkpoint: `{args.model_repo}/{args.checkpoint}`\n")
    lines.append(f"Examples: {args.num_examples}, sequence length: {args.seq_len}, batch size: {args.batch_size}\n")
    lines.append("\n## 1. CE mode comparisons\n")
    for k, v in ce_modes.items():
        lines.append(f"- **{k}**: {v:.6f}\n")
    if utility:
        lines.append(f"- **utility subset routed CE**: {utility['subset_routed_ce']:.6f}\n")
        lines.append(f"- **utility subset forced-dense CE**: {utility['dense_gate_ce']:.6f}\n")
        lines.append(f"- **first-order oracle same-count CE**: {utility['first_order_oracle_same_count_ce']:.6f}\n")

    lines.append("\nInterpretation:\n")
    routed = ce_modes.get("routed")
    dense = ce_modes.get("forced_dense")
    random_ce = ce_modes.get("random_same_count_mean")
    perm = ce_modes.get("permanent_only")
    if routed is not None and dense is not None:
        if dense + 1e-4 < routed:
            lines.append("- Forced-dense is better than routed: the current sparse decisions are removing useful attention contribution.\n")
        elif routed + 1e-4 < dense:
            lines.append("- Routed is better than forced-dense: simply restoring every head does not improve this checkpoint.\n")
        else:
            lines.append("- Routed and forced-dense CE are nearly identical on this diagnostic set.\n")
    if routed is not None and random_ce is not None:
        if routed + 1e-4 < random_ce:
            lines.append("- Routed beats random-same-count: head identity selection contains useful information beyond cardinality.\n")
        else:
            lines.append("- Routed does not clearly beat random-same-count: router identity selection may be weak or heads may be redundant.\n")
    if perm is not None:
        lines.append(f"- Permanent-only gap vs routed: {perm-routed:+.6f} CE.\n")

    lines.append("\n## 2. Router/cardinality summary\n")
    for li in range(len(router_stats["per_layer"])):
        s = router_stats["per_layer"][li]
        lines.append(
            f"- L{li:02d}: actual={s['actual_mean']:.2f}, target={s['target_mean']:.2f}, "
            f"MAE={s['count_mae']:.2f}, rho(easy,count)={s['easiness_actual_spearman']:.3f}, "
            f"dynamic_heads={100*s['dynamic_head_fraction_05_95']:.1f}%, "
            f"mask_hamming={s['expected_pairwise_mask_hamming']:.3f}, "
            f"sat={100*s['sigmoid_saturation_lt05_gt95']:.1f}%, "
            f"STE'={s['ste_derivative_mean']:.4f}, Wnorm={s['router_weight_norm_mean']:.2f}\n"
        )

    lines.append("\n## 3. Router vs CE head utility\n")
    if utility:
        for li in range(len(utility["per_layer"])):
            u = utility["per_layer"][li]
            lines.append(
                f"- L{li:02d}: rho(logit, |dCE/dgate|)={u['logit_importance_spearman_mean']:.3f}, "
                f"top-k overlap={u['router_topk_overlap_with_utility_mean']:.3f}, "
                f"selected/inactive utility={u['selected_to_inactive_importance_ratio_mean']:.3f}\n"
            )
        oracle = utility["first_order_oracle_same_count_ce"]
        subset = utility["subset_routed_ce"]
        if oracle + 1e-4 < subset:
            lines.append("\nThe approximate same-count utility oracle beats HELM routing on the utility subset, suggesting head-selection quality has room to improve.\n")
        else:
            lines.append("\nThe approximate utility oracle does not materially beat HELM on the utility subset; redundancy/mixing may matter more than selector capacity.\n")
    else:
        lines.append("Utility analysis was skipped.\n")

    lines.append("\n## 4. Functional redundancy\n")
    for li, r in redundancy.items():
        f = r["functional_similarity"]
        p = r["parameter_similarity"]
        lines.append(
            f"- L{li:02d}: functional entropy-rank={r['functional_entropy_effective_rank']:.2f}/32, "
            f"participation-rank={r['functional_participation_rank']:.2f}/32, "
            f"mean |functional cosine|={f['mean_abs']:.3f}, "
            f"frac |cos|>.8={100*f['frac_abs_gt_0.8']:.1f}%, "
            f"mean |parameter cosine|={p['mean_abs']:.3f}\n"
        )
        lines.append(f"  - Highest functional-similarity pairs: {r['top_functional_pairs']}\n")

    lines.append("\n### How to use this for the proposed nonlinear 1024→2048 refinement\n")
    lines.append(
        "- If functional effective rank is low / output similarities are high even though parameter similarities are modest, "
        "the expanded attention head bank is producing redundant residual features. That is evidence worth testing a nonlinear "
        "head-refinement/expansion ablation.\n"
    )
    lines.append(
        "- If head outputs are diverse but router-logit/utility alignment is poor and random-same-count is competitive, the "
        "attention expansion is probably not the first bottleneck; the selector is.\n"
    )
    lines.append(
        "- If head outputs are diverse and router selection is good, but dense still beats routed, the 0/1 mixture may be too "
        "coarse; that is the strongest case for testing weighted active-head contributions next.\n"
    )

    if exact is not None:
        lines.append("\n## 5. Exact dense single-head ablations\n")
        deltas = np.array([r["delta_ce"] for r in exact["rows"]])
        lines.append(f"Mean ΔCE: {deltas.mean():+.6f}; max ΔCE: {deltas.max():+.6f}; min ΔCE: {deltas.min():+.6f}\n")

    (output_dir / "summary.md").write_text("".join(lines))


def main():
    parser = argparse.ArgumentParser(description="Analyze HELM_7c checkpoint head dynamics")
    parser.add_argument("--model-repo", default=MODEL_REPO)
    parser.add_argument("--checkpoint", default=CHECKPOINT_FILE)
    parser.add_argument("--data-repo", default=DATA_REPO)
    parser.add_argument("--validation-file", default=VALIDATION_FILE)
    parser.add_argument("--device", choices=["auto", "cuda", "xla", "cpu"], default="auto")
    parser.add_argument("--num-examples", type=int, default=16,
                        help="Diagnostic examples. 16 is enough for first pass; use 32/64 for stronger statistics.")
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--seq-len", type=int, default=1024)
    parser.add_argument("--layers", default="0,5,11", help="Layers for functional redundancy plots")
    parser.add_argument("--utility-batches", type=int, default=4,
                        help="Batches for backward gate-importance + same-count oracle")
    parser.add_argument("--functional-batches", type=int, default=4)
    parser.add_argument("--functional-sample-tokens", type=int, default=16)
    parser.add_argument("--random-trials", type=int, default=3)
    parser.add_argument("--exact-ablation", action="store_true",
                        help="Slow: dense-minus-one-head exact CE for selected layers")
    parser.add_argument("--exact-ablation-batches", type=int, default=2)
    parser.add_argument("--seed", type=int, default=67)
    parser.add_argument("--cache-dir", default="./helm7c_analysis_cache")
    parser.add_argument("--output-dir", default="./helm7c_head_analysis")
    args = parser.parse_args()

    selected_layers = [int(x.strip()) for x in args.layers.split(",") if x.strip()]
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = Path(args.cache_dir)
    seed_everything(args.seed)

    print("=" * 80)
    print("HELM_7c HEAD DYNAMICS ANALYSIS")
    print("=" * 80)
    print("This is a read-only checkpoint analysis. Model parameters will not be updated.\n")

    token = get_hf_token()
    ckpt_path, training_state_path, validation_path = download_assets(
        cache_dir, token, args.model_repo, args.checkpoint, args.data_repo, args.validation_file
    )
    breakpoints = load_breakpoints(training_state_path)
    if breakpoints is None:
        print("WARNING: easiness breakpoints unavailable. The model can still load, but target-head diagnostics need them.")

    dev = resolve_device(args.device)
    print(f"Analysis device: {dev.device} ({dev.kind})")
    model, config = load_model(ckpt_path, breakpoints, dev)
    if breakpoints is None:
        # Router target mapping requires breakpoints. Estimate them from the validation examples only
        # as a fallback; this is explicitly less faithful than training_state.json.
        vals = pq.read_table(str(validation_path), columns=["easiness_score"]).column("easiness_score").to_numpy(zero_copy_only=False)
        vals = np.asarray(vals, dtype=np.float64)
        vals = vals[np.isfinite(vals)]
        breakpoints = np.quantile(vals, np.linspace(0.0, 1.0, 101)).tolist()
        model.config.easiness_cdf_breakpoints = breakpoints
        for block in model.model.blocks:
            block.mlt_vw_rtr.config.easiness_cdf_breakpoints = breakpoints
        print("Fallback: estimated 101 easiness breakpoints from validation data.")

    batches = prepare_batches(
        validation_path, config, args.num_examples, args.batch_size, args.seq_len, args.seed
    )

    print("\n[1/5] Router/cardinality statistics...")
    router_stats = collect_router_statistics(model, batches, dev, output_dir, selected_layers)
    print(f"  Routed diagnostic CE: {router_stats['routed_ce']:.6f}")

    print("\n[2/5] Controlled CE comparisons...")
    ce_modes = {
        "routed": router_stats["routed_ce"],
        "forced_dense": evaluate_override_mode(model, batches, dev, "dense", args.seed),
        "permanent_only": evaluate_override_mode(model, batches, dev, "permanent_only", args.seed),
    }
    random_vals = []
    for trial in range(args.random_trials):
        v = evaluate_override_mode(model, batches, dev, "random_same_count", args.seed + 1000 + trial)
        random_vals.append(v)
        print(f"  Random same-count trial {trial}: {v:.6f}")
    ce_modes["random_same_count_mean"] = float(np.mean(random_vals))
    ce_modes["random_same_count_std"] = float(np.std(random_vals))
    print("  CE modes:", ce_modes)

    print("\n[3/5] Router vs CE-utility alignment (temporary gates; no parameter updates)...")
    utility = utility_alignment_analysis(
        model, batches, dev, min(args.utility_batches, len(batches)), output_dir
    )
    print(
        f"  subset routed={utility['subset_routed_ce']:.6f} | "
        f"dense={utility['dense_gate_ce']:.6f} | "
        f"first-order oracle same-count={utility['first_order_oracle_same_count_ce']:.6f}"
    )

    print("\n[4/5] Functional + parameter redundancy...")
    redundancy = functional_redundancy_analysis(
        model, batches, dev, selected_layers,
        min(args.functional_batches, len(batches)),
        args.functional_sample_tokens,
        output_dir,
    )
    for li, r in redundancy.items():
        print(
            f"  L{li}: functional effective rank={r['functional_entropy_effective_rank']:.2f}/32, "
            f"mean |cos|={r['functional_similarity']['mean_abs']:.3f}"
        )

    exact = None
    if args.exact_ablation:
        print("\n[5/5] Exact single-head dense ablation (slow)...")
        exact = exact_ablation_analysis(
            model, batches, dev, selected_layers,
            min(args.exact_ablation_batches, len(batches)), output_dir
        )
    else:
        print("\n[5/5] Exact single-head ablation skipped (use --exact-ablation to enable).")

    summary_payload = {
        "args": vars(args),
        "checkpoint": f"{args.model_repo}/{args.checkpoint}",
        "ce_modes": ce_modes,
        "router_per_layer": router_stats["per_layer"],
        "utility": utility,
        "redundancy": redundancy,
        "exact_ablation": exact,
    }
    with (output_dir / "summary.json").open("w") as f:
        json.dump(json_safe(summary_payload), f, indent=2)

    write_summary(output_dir, args, router_stats, ce_modes, utility, redundancy, exact)

    archive_base = output_dir / "HELM_7c_head_analysis_results"
    archive_path = shutil.make_archive(str(archive_base), "zip", root_dir=output_dir)
    print("\n" + "=" * 80)
    print("ANALYSIS COMPLETE")
    print(f"Summary: {output_dir / 'summary.md'}")
    print(f"JSON:    {output_dir / 'summary.json'}")
    print(f"ZIP:     {archive_path}")
    print("Send me summary.md + the ZIP (or at least summary.json and the CSVs) and I can interpret it.")
    print("=" * 80)


if __name__ == "__main__":
    main()
