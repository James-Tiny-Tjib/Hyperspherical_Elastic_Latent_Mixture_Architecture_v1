HELM_7c checkpoint analysis
===========================

Files:
  analyze_helm7c_heads.py
  model.py

Default checkpoint:
  JamesResearch1216/HELM_7c / checkpoint-006500.pt

Default validation shard:
  JamesResearch1216/HELM-Easiness-Data-10B-Labeled-v6
  data/seq_1024/validation-00000.parquet

Recommended first run on your existing Kaggle TPU environment:
  python analyze_helm7c_heads.py --device xla --batch-size 2 --num-examples 16

If you have CUDA:
  python analyze_helm7c_heads.py --device cuda --batch-size 2 --num-examples 16

For more stable statistics after the first successful run:
  python analyze_helm7c_heads.py --device xla --batch-size 2 --num-examples 32 --utility-batches 8 --functional-batches 8

Slow optional exact ablation:
  python analyze_helm7c_heads.py --device xla --exact-ablation --exact-ablation-batches 2

Expected dependencies are already present in the HELM training environment:
  torch, torch_xla (for TPU), transformers, safetensors,
  huggingface_hub, pyarrow, numpy, matplotlib

The script writes ./helm7c_head_analysis/ and creates:
  ./helm7c_head_analysis/HELM_7c_head_analysis_results.zip

Send summary.md plus the result ZIP back to ChatGPT for interpretation.
