# HELM_7e vs Dense-32 attention anatomy

## Interpretation

- Lower QK entropy = more concentrated reading, but is not automatically better.
- `attention_mixing_gain_power = context_power / value_power` measures how attention mixing changes V energy.
- `output_block_frobenius` measures head-specific W_O block strength.
- `alignment_gain = 1` is the isotropic-context reference. >1 means C_h covariance aligns with strong W_O directions; <1 means it avoids them.
- `OV operator stable rank` describes the intrinsic low-rank write transform, not output magnitude.
- Current gradient probe (if enabled) is local checkpoint information, NOT training history.

## Key layer averages

| model | L | QK norm entropy | max attn p | V RMS | C RMS | Y RMS | W_O norm | align gain | OV stable rank |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Dense-32 | 0 | 0.7907 | 0.0783 | 0.06159 | 0.04062 | 0.01517 | 5.6526 | 4.3205 | 7.32 |
| Dense-32 | 1 | 0.7800 | 0.0792 | 0.05307 | 0.03260 | 0.01136 | 5.6516 | 3.8483 | 9.38 |
| Dense-32 | 2 | 0.6126 | 0.1766 | 0.04268 | 0.02015 | 0.00601 | 5.6482 | 2.7980 | 8.93 |
| Dense-32 | 3 | 0.4557 | 0.3116 | 0.03630 | 0.01872 | 0.00572 | 5.6418 | 2.8902 | 7.68 |
| Dense-32 | 4 | 0.3808 | 0.4081 | 0.03368 | 0.01471 | 0.00368 | 5.6313 | 1.9015 | 10.21 |
| Dense-32 | 5 | 0.4808 | 0.2824 | 0.03303 | 0.01519 | 0.00401 | 5.6192 | 2.1477 | 8.77 |
| Dense-32 | 6 | 0.3018 | 0.5417 | 0.02906 | 0.01031 | 0.00245 | 5.5784 | 1.8069 | 13.62 |
| Dense-32 | 7 | 0.3252 | 0.4813 | 0.02713 | 0.01143 | 0.00266 | 5.6118 | 1.9779 | 12.68 |
| Dense-32 | 8 | 0.3831 | 0.4056 | 0.03416 | 0.01443 | 0.00334 | 5.6281 | 1.6659 | 11.23 |
| Dense-32 | 9 | 0.4351 | 0.3637 | 0.03259 | 0.01267 | 0.00285 | 5.5999 | 1.6326 | 11.52 |
| Dense-32 | 10 | 0.3926 | 0.4055 | 0.02996 | 0.01190 | 0.00258 | 5.6151 | 1.5102 | 12.69 |
| Dense-32 | 11 | 0.3596 | 0.4577 | 0.02879 | 0.01083 | 0.00210 | 5.5682 | 1.3323 | 17.45 |
| HELM_7e | 0 | 0.7469 | 0.1065 | 0.05898 | 0.03213 | 0.01128 | 5.6343 | 3.5044 | 7.99 |
| HELM_7e | 1 | 0.6796 | 0.1292 | 0.05350 | 0.02260 | 0.00749 | 5.6452 | 3.3666 | 8.46 |
| HELM_7e | 2 | 0.6384 | 0.1619 | 0.04251 | 0.01342 | 0.00402 | 5.6429 | 2.6224 | 9.02 |
| HELM_7e | 3 | 0.5057 | 0.2953 | 0.04437 | 0.01411 | 0.00395 | 5.6180 | 2.1656 | 10.48 |
| HELM_7e | 4 | 0.4607 | 0.3524 | 0.03781 | 0.01414 | 0.00409 | 5.6037 | 2.2860 | 8.94 |
| HELM_7e | 5 | 0.2016 | 0.6671 | 0.03617 | 0.01154 | 0.00281 | 5.5910 | 1.6918 | 12.90 |
| HELM_7e | 6 | 0.2389 | 0.6351 | 0.03508 | 0.00986 | 0.00230 | 5.6132 | 1.5926 | 13.98 |
| HELM_7e | 7 | 0.1907 | 0.6972 | 0.03468 | 0.00931 | 0.00215 | 5.5933 | 1.5649 | 14.13 |
| HELM_7e | 8 | 0.1758 | 0.7146 | 0.03359 | 0.00953 | 0.00212 | 5.6068 | 1.5575 | 14.98 |
| HELM_7e | 9 | 0.1601 | 0.7293 | 0.03511 | 0.00823 | 0.00180 | 5.5975 | 1.4377 | 14.85 |
| HELM_7e | 10 | 0.2514 | 0.6132 | 0.03306 | 0.00924 | 0.00215 | 5.5654 | 1.5364 | 13.77 |
| HELM_7e | 11 | 0.2207 | 0.6408 | 0.03139 | 0.00942 | 0.00182 | 5.5746 | 1.2753 | 20.98 |

## What to look for

### If HELM_7e has normal QK metrics but low residual RMS
The deficit is primarily on the WRITE side, not attention selection.

### If C RMS is already much lower in HELM_7e
Magnitude is being lost inside V/attention mixing before W_O.

### If C RMS is similar but W_O norms are much smaller/more unequal
The write projection is the main magnitude bottleneck; head-normalized W_O / explicit head gates become a targeted ablation.

### If C RMS and W_O norms are similar but alignment_gain is lower
The issue is orientation: head contexts are poorly matched to their W_O subspaces.

### If QK entropy/logit contrast differs strongly
The router is changing what heads learn to READ, so an MLP/nonlinear head-combination fix may be downstream of the true problem.